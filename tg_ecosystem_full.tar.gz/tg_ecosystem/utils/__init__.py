"""
utils/__init__.py
Вспомогательные утилиты экосистемы.
"""
import re


def sanitize_slug(text: str) -> str:
    """Превратить произвольную строку в валидный slug."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_-]+", "_", text)
    return text[:64]


def format_dt(dt) -> str:
    """Форматировать datetime для вывода в Telegram."""
    if dt is None:
        return "—"
    return dt.strftime("%d.%m.%Y %H:%M")


def mask_token(token: str) -> str:
    """Скрыть большую часть токена бота для безопасного отображения."""
    if ":" not in token:
        return "***"
    bot_id, secret = token.split(":", 1)
    return f"{bot_id}:{'*' * (len(secret) - 4)}{secret[-4:]}"
