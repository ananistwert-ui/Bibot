"""
main.py
Точка входа в экосистему Telegram-проектов.

Запуск:
    python main.py

Переменные окружения:
    Скопируйте .env.example в .env и заполните значения.
"""
import asyncio
from bot.orchestrator import run_ecosystem

if __name__ == "__main__":
    asyncio.run(run_ecosystem())
