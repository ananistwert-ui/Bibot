# Telegram Ecosystem — Единая инфраструктура проектов

Централизованная система управления Telegram-проектами:
один новостной канал, неограниченное количество проектов,
единая воронка, единая БД, один Супер Администратор.

---

## Структура проекта

```
tg_ecosystem/
├── main.py                  # Точка входа
├── setup_project.py         # Мастер первоначальной настройки
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example             # Шаблон переменных окружения
│
├── core/
│   └── config.py            # Конфигурация из .env
│
├── db/
│   ├── models/              # SQLAlchemy ORM-модели
│   │   └── __init__.py      # Project, User, UserProjectAccess, ...
│   ├── repositories/        # Весь доступ к данным
│   │   └── __init__.py
│   └── engine.py            # Движок и фабрика сессий
│
├── bot/
│   ├── orchestrator.py      # Запускает всех ботов одновременно
│   ├── handlers/
│   │   ├── user.py          # Воронка пользователя
│   │   └── admin.py         # Команды Супер Администратора
│   ├── middlewares/         # DB-сессия, проект
│   ├── keyboards/           # Все inline-клавиатуры
│   └── filters/             # IsSuperAdmin, HasProject
│
└── utils/                   # Вспомогательные функции
```

---

## Быстрый старт (разработка)

### 1. Клонировать и настроить окружение

```bash
git clone <repo>
cd tg_ecosystem
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Создать .env

```bash
cp .env.example .env
```

Заполнить в `.env`:

| Переменная | Описание |
|---|---|
| `ADMIN_BOT_TOKEN` | Токен главного бота (для Супер Админа) |
| `SUPER_ADMIN_ID` | Ваш Telegram ID |
| `NEWS_CHANNEL_ID` | ID Новостного Канала (с минусом) |
| `DATABASE_URL` | SQLite (dev) или PostgreSQL (prod) |

### 3. Добавить первый проект

```bash
python setup_project.py
```

Скрипт спросит: название, slug, токен бота проекта, ID приватного канала.

### 4. Запустить экосистему

```bash
python main.py
```

Система запустит Admin Bot + все активные Project Bot'ы в одном процессе.

---

## Продакшн (Docker)

```bash
# Создать .env с продакшн-значениями (PostgreSQL URL)
cp .env.example .env
nano .env

# Поднять всё
docker compose up -d

# Добавить проект (один раз)
docker compose exec ecosystem python setup_project.py

# Логи
docker compose logs -f ecosystem
```

---

## Воронка пользователя

```
/start {source}  →  CAPTCHA  →  Проверка подписки
                                      ↓
                          Одноразовый Invite Link
                                      ↓
                          Join Request → Бот проверяет:
                            1. captcha_verified
                            2. subscription_verified
                            3. не заблокирован
                                      ↓
                     approveChatJoinRequest() → Уведомление
```

---

## Команды Супер Администратора

| Команда | Действие |
|---|---|
| `/admin` | Открыть панель управления |
| `/export` | Скачать CSV со всеми пользователями |

Через инлайн-меню доступно:
- Список проектов с количеством участников
- Добавление нового проекта (FSM, 4 шага)
- Статистика по проекту
- Источники трафика с процентами
- Активация / пауза / удаление проекта
- Общая статистика экосистемы

---

## Добавление нового проекта (без скрипта)

1. Создать бота через @BotFather → получить токен
2. Создать приватный канал → сделать бота администратором
3. В Telegram написать Admin Bot → `/admin` → «Добавить проект»
4. Пройти 4 шага FSM-мастера
5. Проект автоматически встраивается в инфраструктуру

---

## База данных

| Таблица | Назначение |
|---|---|
| `projects` | Проекты экосистемы |
| `users` | Telegram-пользователи |
| `user_project_access` | Статус каждого пользователя в каждом проекте |
| `user_events` | Полный лог действий |
| `traffic_sources` | Источники трафика по проектам |
| `blocked_users` | Блокировки (per-project или глобальные) |

---

## Масштабирование

Для добавления нового проекта достаточно:
1. Создать бота у @BotFather
2. Добавить проект через Admin Bot
3. Перезапустить `main.py` (или использовать hot-reload)

Никакого нового кода писать не нужно.
