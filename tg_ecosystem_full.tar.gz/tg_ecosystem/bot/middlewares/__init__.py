"""
bot/middlewares/__init__.py
Middleware слой: DB-сессия, проект, антиспам.
"""
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Update
from sqlalchemy.ext.asyncio import async_sessionmaker, AsyncSession

from db.repositories import (
    AccessRepository, BlockedRepository, EventRepository,
    ProjectRepository, TrafficRepository, UserRepository,
)


# ─── DbSessionMiddleware ──────────────────────────────────────────────────────

class DbSessionMiddleware(BaseMiddleware):
    """
    Открывает сессию БД на каждый апдейт и кладёт её в data.
    Автоматически делает commit/rollback.
    """

    def __init__(self, session_factory: async_sessionmaker[AsyncSession]):
        self.session_factory = session_factory

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        async with self.session_factory() as session:
            async with session.begin():
                # Репозитории доступны в handlers через data["repo_*"]
                data["session"] = session
                data["repo_user"]    = UserRepository(session)
                data["repo_project"] = ProjectRepository(session)
                data["repo_access"]  = AccessRepository(session)
                data["repo_blocked"] = BlockedRepository(session)
                data["repo_event"]   = EventRepository(session)
                data["repo_traffic"] = TrafficRepository(session)
                return await handler(event, data)


# ─── ProjectMiddleware ────────────────────────────────────────────────────────

class ProjectMiddleware(BaseMiddleware):
    """
    Определяет текущий проект по токену бота.
    Кладёт объект Project в data["project"].
    Если проект не найден — пропускает апдейт молча.
    """

    def __init__(self, project_slug: str):
        self.project_slug = project_slug

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        repo: ProjectRepository = data.get("repo_project")
        if repo:
            project = await repo.get_by_slug(self.project_slug)
            data["project"] = project
        return await handler(event, data)
