"""
bot/filters/__init__.py
Кастомные фильтры Aiogram для экосистемы.
"""
from aiogram.filters import BaseFilter
from aiogram.types import Message, CallbackQuery

from core.config import config as cfg


class IsSuperAdmin(BaseFilter):
    """Пропускает только Супер Администратора."""

    async def __call__(self, event: Message | CallbackQuery) -> bool:
        if not cfg:
            return False
        user = event.from_user if hasattr(event, "from_user") else None
        if not user:
            return False
        return user.id == cfg.super_admin_id


class HasProject(BaseFilter):
    """Пропускает апдейт только если проект определён в data."""

    async def __call__(self, event, data: dict) -> bool:
        return data.get("project") is not None
