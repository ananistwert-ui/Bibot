"""
bot/orchestrator.py

EcosystemManager — центральный менеджер всех ботов экосистемы.

КЛЮЧЕВОЕ РЕШЕНИЕ: каждый Dispatcher получает свежий Router через
register_*_handlers() — нельзя подключить один и тот же Router
к нескольким Dispatcher'ам (Aiogram 3 запрещает, frozen parent).
"""
import asyncio
import logging
import os
import sys
from dataclasses import dataclass

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from bot.middlewares import DbSessionMiddleware, ProjectMiddleware
from core.config import config as cfg
from db.engine import get_session_factory, init_db
from db.models import Project
from db.repositories import ProjectRepository

log = logging.getLogger(__name__)

# Глобальная ссылка — доступна из admin.py
ecosystem_manager: "EcosystemManager | None" = None

PID_FILE = "/tmp/tg_ecosystem.pid"


# ─── PID защита ───────────────────────────────────────────────────────────────

def _write_pid() -> None:
    if os.path.exists(PID_FILE):
        with open(PID_FILE) as f:
            old_pid = f.read().strip()
        try:
            os.kill(int(old_pid), 0)
            log.error(
                "Экосистема уже запущена (PID %s). "
                "Если это ошибка — удалите: %s",
                old_pid, PID_FILE,
            )
            sys.exit(1)
        except (ProcessLookupError, ValueError):
            pass
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))


def _remove_pid() -> None:
    try:
        os.remove(PID_FILE)
    except FileNotFoundError:
        pass


# ─── Builders ─────────────────────────────────────────────────────────────────

def _build_project_dp(slug: str, session_factory) -> Dispatcher:
    """
    Создаём НОВЫЙ Dispatcher и НОВЫЙ Router для каждого проекта.
    Нельзя переиспользовать один router — Aiogram 3 запрещает
    подключать один Router к нескольким Dispatcher'ам.
    """
    from bot.handlers.user import register_user_handlers
    dp = Dispatcher(storage=MemoryStorage())
    dp.update.middleware(DbSessionMiddleware(session_factory))
    dp.update.middleware(ProjectMiddleware(slug))
    dp.include_router(register_user_handlers())
    return dp


def _build_admin_dp(session_factory) -> Dispatcher:
    from bot.handlers.admin import register_admin_handlers
    dp = Dispatcher(storage=MemoryStorage())
    dp.update.middleware(DbSessionMiddleware(session_factory))
    dp.include_router(register_admin_handlers())
    return dp


# ─── EcosystemManager ────────────────────────────────────────────────────────

@dataclass
class _RunningBot:
    slug: str
    task: asyncio.Task
    bot: Bot


class EcosystemManager:
    def __init__(self, session_factory):
        self._session_factory = session_factory
        self._running: dict[str, _RunningBot] = {}
        self._admin_task: asyncio.Task | None = None
        self._admin_bot: Bot | None = None

    async def start_admin(self) -> None:
        if not cfg:
            log.error("Конфигурация не загружена — Admin Bot не запустится")
            return
        bot = Bot(
            token=cfg.admin_bot_token,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        )
        dp = _build_admin_dp(self._session_factory)
        self._admin_bot = bot
        self._admin_task = asyncio.create_task(
            self._polling_loop(bot, dp, name="admin"),
            name="bot:admin",
        )
        log.info("▶ Admin Bot запущен (super_admin_id=%s)", cfg.super_admin_id)

    async def start_project(self, project: Project) -> bool:
        """Запустить бота проекта. Возвращает True если запустили."""
        slug = project.slug
        if slug in self._running:
            log.info("Бот проекта %s уже запущен — пропуск", slug)
            return False

        bot = Bot(
            token=project.bot_token,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        )
        dp = _build_project_dp(slug, self._session_factory)

        task = asyncio.create_task(
            self._polling_loop(bot, dp, name=slug),
            name=f"bot:{slug}",
        )
        self._running[slug] = _RunningBot(slug=slug, task=task, bot=bot)
        log.info("▶ Бот проекта запущен: %s", slug)
        return True

    async def stop_project(self, project_id_or_slug: str) -> None:
        slug = project_id_or_slug
        entry = self._running.get(slug)
        if entry is None:
            log.info("Бот %s не найден в запущенных", project_id_or_slug)
            return
        entry.task.cancel()
        try:
            await entry.task
        except (asyncio.CancelledError, Exception):
            pass
        await entry.bot.session.close()
        del self._running[slug]
        log.info("⏹ Бот проекта остановлен: %s", slug)

    def running_slugs(self) -> list[str]:
        return list(self._running.keys())

    async def shutdown(self) -> None:
        log.info("Остановка всех ботов...")
        tasks = []
        for entry in self._running.values():
            entry.task.cancel()
            tasks.append(entry.task)
        if self._admin_task:
            self._admin_task.cancel()
            tasks.append(self._admin_task)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        for entry in self._running.values():
            try:
                await entry.bot.session.close()
            except Exception:
                pass
        if self._admin_bot:
            try:
                await self._admin_bot.session.close()
            except Exception:
                pass
        self._running.clear()
        log.info("Все боты остановлены.")

    async def _polling_loop(self, bot: Bot, dp: Dispatcher, name: str) -> None:
        """Polling с авторестартом. Падение одного бота не роняет остальных."""
        retry_delay = 5
        while True:
            try:
                await dp.start_polling(
                    bot,
                    allowed_updates=dp.resolve_used_update_types(),
                    drop_pending_updates=True,
                )
                break
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error("Бот [%s] упал: %s. Перезапуск через %ds...", name, e, retry_delay)
                await asyncio.sleep(retry_delay)
                retry_delay = min(retry_delay * 2, 60)


# ─── Точка входа ─────────────────────────────────────────────────────────────

async def run_ecosystem() -> None:
    global ecosystem_manager

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    if not cfg:
        log.error("Не задан ADMIN_BOT_TOKEN. Проверьте .env файл.")
        return

    _write_pid()

    try:
        await init_db(cfg.database_url)
        session_factory = get_session_factory(cfg.database_url)

        ecosystem_manager = EcosystemManager(session_factory)

        async with session_factory() as session:
            repo = ProjectRepository(session)
            projects = await repo.get_all_active()

        log.info("Найдено активных проектов: %d", len(projects))
        for p in projects:
            log.info("  • %s [%s]", p.name, p.slug)

        await ecosystem_manager.start_admin()
        for project in projects:
            await ecosystem_manager.start_project(project)

        log.info("✅ Экосистема запущена. Ctrl+C для остановки.")

        try:
            while True:
                await asyncio.sleep(1)
        except (KeyboardInterrupt, asyncio.CancelledError):
            pass

    finally:
        if ecosystem_manager:
            await ecosystem_manager.shutdown()
        _remove_pid()
