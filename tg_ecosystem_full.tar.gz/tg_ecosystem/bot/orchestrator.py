"""
bot/orchestrator.py
Запускает одновременно:
  - Главный Admin Bot (управление экосистемой)
  - По одному Bot на каждый активный проект в БД

Все боты работают в одном asyncio event loop через polling.
Для продакшена рекомендуется webhook (каждый бот на свой path).
"""
import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from bot.handlers import admin, user
from bot.middlewares import DbSessionMiddleware, ProjectMiddleware
from core.config import config as cfg
from db.engine import get_session_factory, init_db
from db.repositories import ProjectRepository

log = logging.getLogger(__name__)


def build_project_dispatcher(project_slug: str, session_factory) -> Dispatcher:
    """
    Создать отдельный Dispatcher для конкретного проекта.
    Каждый проект — свой Dispatcher, своя FSM, свои middleware.
    """
    dp = Dispatcher(storage=MemoryStorage())

    # Middleware: сессия БД → проект по slug
    dp.update.middleware(DbSessionMiddleware(session_factory))
    dp.update.middleware(ProjectMiddleware(project_slug))

    # Только пользовательские хендлеры
    dp.include_router(user.router)

    return dp


def build_admin_dispatcher(session_factory) -> Dispatcher:
    """
    Admin Dispatcher обрабатывает команды Супер Администратора.
    Работает на отдельном боте (ADMIN_BOT_TOKEN).
    """
    dp = Dispatcher(storage=MemoryStorage())
    dp.update.middleware(DbSessionMiddleware(session_factory))
    dp.include_router(admin.router)
    return dp


async def start_project_bot(
    token: str,
    slug: str,
    session_factory,
) -> None:
    """Запустить polling для одного проекта."""
    bot = Bot(
        token=token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = build_project_dispatcher(slug, session_factory)

    log.info("Запуск бота проекта: %s", slug)
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()


async def start_admin_bot(session_factory) -> None:
    """Запустить polling для Admin Bot."""
    if not cfg:
        log.error("Конфигурация не загружена, Admin Bot не запустится")
        return

    bot = Bot(
        token=cfg.admin_bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = build_admin_dispatcher(session_factory)

    log.info("Запуск Admin Bot (super_admin_id=%s)", cfg.super_admin_id)
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await bot.session.close()


async def run_ecosystem() -> None:
    """
    Главная точка входа.
    1. Инициализация БД
    2. Загрузка всех активных проектов
    3. Одновременный запуск Admin Bot + всех Project Bot'ов
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    if not cfg:
        log.error("Не задан ADMIN_BOT_TOKEN. Проверьте .env файл.")
        return

    # Инициализировать таблицы
    await init_db(cfg.database_url)
    session_factory = get_session_factory(cfg.database_url)

    # Загрузить активные проекты
    async with session_factory() as session:
        repo = ProjectRepository(session)
        projects = await repo.get_all_active()

    log.info("Найдено активных проектов: %d", len(projects))

    # Собрать все корутины
    tasks = [start_admin_bot(session_factory)]

    for project in projects:
        tasks.append(
            start_project_bot(
                token=project.bot_token,
                slug=project.slug,
                session_factory=session_factory,
            )
        )

    # Запустить все боты одновременно
    await asyncio.gather(*tasks)
