"""
bot/orchestrator.py
Запускает одновременно:
  - Главный Admin Bot (управление экосистемой)
  - По одному Bot на каждый активный проект в БД

Все боты работают в одном asyncio event loop через polling.
Для продакшена рекомендуется webhook (каждый бот на свой path).
"""
import asyncio
import logging
import os
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from bot.handlers import admin, user
from bot.middlewares import DbSessionMiddleware, ProjectMiddleware
from core.config import config as cfg
from db.engine import get_session_factory, init_db
from db.repositories import ProjectRepository

log = logging.getLogger(__name__)

# ─── PID-файл: защита от двойного запуска ─────────────────────────────────────

PID_FILE = "/tmp/tg_ecosystem.pid"


def _write_pid() -> None:
    """Записать PID текущего процесса. Упасть если уже запущен."""
    if os.path.exists(PID_FILE):
        with open(PID_FILE) as f:
            old_pid = f.read().strip()
        # Проверить, живёт ли тот процесс
        try:
            os.kill(int(old_pid), 0)
            # Процесс живёт — значит уже запущен
            log.error(
                "Экосистема уже запущена (PID %s). "
                "Если это ошибка — удалите файл: %s",
                old_pid, PID_FILE,
            )
            sys.exit(1)
        except (ProcessLookupError, ValueError):
            # Процесс не найден — PID-файл устаревший, перезаписываем
            pass

    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))


def _remove_pid() -> None:
    try:
        os.remove(PID_FILE)
    except FileNotFoundError:
        pass


# ─── Builders ─────────────────────────────────────────────────────────────────

def build_project_dispatcher(project_slug: str, session_factory) -> Dispatcher:
    """
    Создать отдельный Dispatcher для конкретного проекта.
    Каждый проект — свой Dispatcher, своя FSM, свои middleware.
    """
    dp = Dispatcher(storage=MemoryStorage())
    dp.update.middleware(DbSessionMiddleware(session_factory))
    dp.update.middleware(ProjectMiddleware(project_slug))
    dp.include_router(user.router)
    return dp


def build_admin_dispatcher(session_factory) -> Dispatcher:
    """
    Admin Dispatcher обрабатывает команды Супер Администратора.
    Работает на отдельном боте (ADMIN_BOT_TOKEN).
    """
    dp = Dispatcher(storage=MemoryStorage())
    dp.update.middleware(DbSessionMiddleware(session_factory))
    dp.include_router(admin.router)
    return dp


# ─── Запуск отдельного бота ───────────────────────────────────────────────────

async def start_project_bot(token: str, slug: str, session_factory) -> None:
    """Запустить polling для одного проекта."""
    bot = Bot(
        token=token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = build_project_dispatcher(slug, session_factory)

    log.info("▶ Запуск бота проекта: %s", slug)
    try:
        await dp.start_polling(
            bot,
            allowed_updates=dp.resolve_used_update_types(),
            # Сбросить накопившиеся апдейты при старте — ключевой параметр
            drop_pending_updates=True,
        )
    except asyncio.CancelledError:
        log.info("⏹ Бот проекта остановлен: %s", slug)
    finally:
        await bot.session.close()


async def start_admin_bot(session_factory) -> None:
    """Запустить polling для Admin Bot."""
    if not cfg:
        log.error("Конфигурация не загружена, Admin Bot не запустится")
        return

    bot = Bot(
        token=cfg.admin_bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = build_admin_dispatcher(session_factory)

    log.info("▶ Запуск Admin Bot (super_admin_id=%s)", cfg.super_admin_id)
    try:
        await dp.start_polling(
            bot,
            allowed_updates=dp.resolve_used_update_types(),
            drop_pending_updates=True,
        )
    except asyncio.CancelledError:
        log.info("⏹ Admin Bot остановлен")
    finally:
        await bot.session.close()


# ─── Главная точка входа ──────────────────────────────────────────────────────

async def run_ecosystem() -> None:
    """
    1. Проверка на двойной запуск (PID-файл)
    2. Инициализация БД
    3. Загрузка всех активных проектов
    4. Одновременный запуск Admin Bot + всех Project Bot'ов
    5. Корректная остановка по Ctrl+C
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    if not cfg:
        log.error("Не задан ADMIN_BOT_TOKEN. Проверьте .env файл.")
        return

    # Защита от двойного запуска
    _write_pid()

    try:
        # Инициализировать таблицы
        await init_db(cfg.database_url)
        session_factory = get_session_factory(cfg.database_url)

        # Загрузить активные проекты
        async with session_factory() as session:
            repo = ProjectRepository(session)
            projects = await repo.get_all_active()

        log.info("Найдено активных проектов: %d", len(projects))
        for p in projects:
            log.info("  • %s [%s]", p.name, p.slug)

        # Собрать все задачи
        tasks = [
            asyncio.create_task(start_admin_bot(session_factory), name="admin_bot")
        ]
        for project in projects:
            tasks.append(asyncio.create_task(
                start_project_bot(project.bot_token, project.slug, session_factory),
                name=f"bot_{project.slug}",
            ))

        log.info("✅ Экосистема запущена. Для остановки нажмите Ctrl+C")

        # Ждём завершения — при Ctrl+C отменяем все задачи
        try:
            await asyncio.gather(*tasks)
        except (KeyboardInterrupt, asyncio.CancelledError):
            log.info("Получен сигнал остановки...")
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            log.info("Все боты остановлены.")

    finally:
        _remove_pid()
