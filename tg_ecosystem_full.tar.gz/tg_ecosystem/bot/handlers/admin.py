"""
bot/handlers/admin.py
Команды и колбэки Супер Администратора.
Доступны только пользователю с SUPER_ADMIN_ID.
"""
import logging
from io import StringIO

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import BufferedInputFile, CallbackQuery, Message

from bot.keyboards import (
    kb_admin_main, kb_admin_project, kb_back_to_admin, kb_confirm_delete,
)
from core.config import config as cfg
from db.models import ProjectStatus
from db.repositories import (
    AccessRepository, ProjectRepository, TrafficRepository, UserRepository,
)

log = logging.getLogger(__name__)
router = Router(name="admin")


# ─── FSM для добавления проекта ───────────────────────────────────────────────

class AddProjectStates(StatesGroup):
    name              = State()
    slug              = State()
    bot_token         = State()
    private_channel   = State()
    news_invite_link  = State()   # ссылка-приглашение на Новостной Канал
    confirm           = State()


# ─── Фильтр: только Супер Администратор ──────────────────────────────────────

def is_admin(user_id: int) -> bool:
    return bool(cfg and user_id == cfg.super_admin_id)


# ─── Вспомогательная функция отрисовки меню проекта ─────────────────────────
# Вместо мутации cb.data — просто вызываем edit_text напрямую.

async def _render_project_menu(
    message: Message,
    project_id: str,
    repo_project: ProjectRepository,
) -> None:
    project = await repo_project.get_by_id(project_id)
    if not project:
        await message.edit_text("Проект не найден.", reply_markup=kb_back_to_admin())
        return

    status_label = {
        "active": "✅ Активен",
        "paused": "⏸ Приостановлен",
        "setup":  "⚙️ Настройка",
    }.get(project.status, project.status)

    await message.edit_text(
        f"📁 <b>{project.name}</b>\n"
        f"Slug: <code>{project.slug}</code>\n"
        f"Статус: {status_label}\n"
        f"Канал ID: <code>{project.private_channel_id}</code>",
        reply_markup=kb_admin_project(project_id),
        parse_mode="HTML",
    )


# ─── /admin ───────────────────────────────────────────────────────────────────

@router.message(Command("admin"))
async def cmd_admin(message: Message) -> None:
    if not is_admin(message.from_user.id):
        return

    await message.answer(
        "👤 <b>Панель Супер Администратора</b>\n\n"
        "Выберите действие:",
        reply_markup=kb_admin_main(),
        parse_mode="HTML",
    )


# ─── Callback: главное меню ───────────────────────────────────────────────────

@router.callback_query(F.data == "admin:main")
async def cb_admin_main(cb: CallbackQuery) -> None:
    if not is_admin(cb.from_user.id):
        return
    await cb.answer()
    await cb.message.edit_text(
        "👤 <b>Панель Супер Администратора</b>\n\n"
        "Выберите действие:",
        reply_markup=kb_admin_main(),
        parse_mode="HTML",
    )


# ─── Callback: список проектов ────────────────────────────────────────────────

@router.callback_query(F.data == "admin:projects")
async def cb_projects_list(
    cb: CallbackQuery,
    repo_project: ProjectRepository,
    repo_access: AccessRepository,
) -> None:
    if not is_admin(cb.from_user.id):
        return
    await cb.answer()

    projects = await repo_project.get_all()
    if not projects:
        await cb.message.edit_text(
            "Проектов пока нет. Добавьте первый!",
            reply_markup=kb_admin_main(),
        )
        return

    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    buttons = []
    for p in projects:
        count = await repo_access.count_approved(p.id)
        icon = {"active": "✅", "paused": "⏸", "setup": "⚙️"}.get(p.status, "❓")
        buttons.append([InlineKeyboardButton(
            text=f"{icon} {p.name} ({count} уч.)",
            callback_data=f"proj:manage:{p.id}",
        )])
    buttons.append([InlineKeyboardButton(text="◀️ Назад", callback_data="admin:main")])

    await cb.message.edit_text(
        f"📋 <b>Проекты экосистемы</b> ({len(projects)})",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode="HTML",
    )


# ─── Callback: управление проектом ───────────────────────────────────────────

@router.callback_query(F.data.startswith("proj:manage:"))
async def cb_manage_project(
    cb: CallbackQuery,
    repo_project: ProjectRepository,
) -> None:
    if not is_admin(cb.from_user.id):
        return
    await cb.answer()
    project_id = cb.data.split(":", 2)[-1]
    await _render_project_menu(cb.message, project_id, repo_project)


# ─── Callback: статистика проекта ─────────────────────────────────────────────

@router.callback_query(F.data.startswith("proj:stats:"))
async def cb_project_stats(
    cb: CallbackQuery,
    repo_project: ProjectRepository,
    repo_access: AccessRepository,
    repo_traffic: TrafficRepository,
) -> None:
    if not is_admin(cb.from_user.id):
        return
    await cb.answer()

    project_id = cb.data.split(":", 2)[-1]
    project = await repo_project.get_by_id(project_id)
    if not project:
        return

    approved = await repo_access.count_approved(project_id)
    sources = await repo_traffic.get_stats(project_id)

    src_lines = "\n".join(
        f"  • {s.slug}: <b>{s.total_clicks}</b>"
        for s in sources[:10]
    ) or "  Нет данных"

    await cb.message.edit_text(
        f"📊 <b>Статистика: {project.name}</b>\n\n"
        f"👥 Участников: <b>{approved}</b>\n\n"
        f"🔗 Источники трафика:\n{src_lines}",
        reply_markup=kb_admin_project(project_id),
        parse_mode="HTML",
    )


# ─── Callback: источники трафика ──────────────────────────────────────────────

@router.callback_query(F.data.startswith("proj:traffic:"))
async def cb_traffic(
    cb: CallbackQuery,
    repo_project: ProjectRepository,
    repo_traffic: TrafficRepository,
) -> None:
    if not is_admin(cb.from_user.id):
        return
    await cb.answer()

    project_id = cb.data.split(":", 2)[-1]
    project = await repo_project.get_by_id(project_id)
    sources = await repo_traffic.get_stats(project_id)

    if not sources:
        text = f"🔗 <b>Источники трафика: {project.name}</b>\n\nДанных пока нет."
    else:
        total = sum(s.total_clicks for s in sources)
        lines = []
        for i, s in enumerate(sources, 1):
            pct = round(s.total_clicks / total * 100) if total else 0
            bar = "█" * (pct // 10) + "░" * (10 - pct // 10)
            lines.append(f"{i}. {s.slug}\n   {bar} {s.total_clicks} ({pct}%)")
        text = (
            f"🔗 <b>Источники трафика: {project.name}</b>\n"
            f"Итого кликов: {total}\n\n" + "\n\n".join(lines)
        )

    await cb.message.edit_text(
        text,
        reply_markup=kb_admin_project(project_id),
        parse_mode="HTML",
    )


# ─── Callback: активация ─────────────────────────────────────────────────────
# ИСПРАВЛЕНО: убрана мутация cb.data — вместо этого вызываем _render_project_menu напрямую

@router.callback_query(F.data.startswith("proj:activate:"))
async def cb_activate(
    cb: CallbackQuery,
    repo_project: ProjectRepository,
) -> None:
    if not is_admin(cb.from_user.id):
        return
    project_id = cb.data.split(":", 2)[-1]
    await repo_project.set_status(project_id, ProjectStatus.active)
    await cb.answer("✅ Проект активирован")

    # Сигнализируем оркестратору что надо запустить новый бот
    from bot.orchestrator import ecosystem_manager
    if ecosystem_manager:
        project = await repo_project.get_by_id(project_id)
        if project:
            await ecosystem_manager.start_project(project)

    await _render_project_menu(cb.message, project_id, repo_project)


# ─── Callback: пауза ─────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("proj:pause:"))
async def cb_pause(
    cb: CallbackQuery,
    repo_project: ProjectRepository,
) -> None:
    if not is_admin(cb.from_user.id):
        return
    project_id = cb.data.split(":", 2)[-1]
    await repo_project.set_status(project_id, ProjectStatus.paused)
    await cb.answer("⏸ Проект приостановлен")

    from bot.orchestrator import ecosystem_manager
    if ecosystem_manager:
        await ecosystem_manager.stop_project(project_id)

    await _render_project_menu(cb.message, project_id, repo_project)


# ─── Callback: удаление ───────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("proj:delete:"))
async def cb_delete_confirm_prompt(cb: CallbackQuery) -> None:
    if not is_admin(cb.from_user.id):
        return
    # Пропускаем если это уже confirm
    if "confirm" in cb.data:
        return
    await cb.answer()
    project_id = cb.data.split(":", 2)[-1]
    await cb.message.edit_text(
        "⚠️ <b>Вы уверены?</b>\n\nПроект и все его данные будут удалены безвозвратно.",
        reply_markup=kb_confirm_delete(project_id),
        parse_mode="HTML",
    )


@router.callback_query(F.data.startswith("proj:delete_confirm:"))
async def cb_delete_confirmed(
    cb: CallbackQuery,
    repo_project: ProjectRepository,
) -> None:
    if not is_admin(cb.from_user.id):
        return
    project_id = cb.data.split(":", 2)[-1]

    # Остановить бот проекта если запущен
    from bot.orchestrator import ecosystem_manager
    if ecosystem_manager:
        await ecosystem_manager.stop_project(project_id)

    # Удалить из БД
    from sqlalchemy import delete as sql_delete
    from db.models import Project
    session = repo_project.session
    await session.execute(sql_delete(Project).where(Project.id == project_id))

    await cb.answer("🗑 Проект удалён")
    await cb.message.edit_text("Проект удалён.", reply_markup=kb_admin_main())


# ─── Callback / FSM: добавление проекта ──────────────────────────────────────

@router.callback_query(F.data == "admin:add_project")
async def cb_start_add_project(cb: CallbackQuery, state: FSMContext) -> None:
    if not is_admin(cb.from_user.id):
        return
    await cb.answer()
    await state.set_state(AddProjectStates.name)
    await cb.message.edit_text(
        "➕ <b>Добавление нового проекта</b>\n\n"
        "Шаг 1/5 — Введите <b>название</b> проекта\n"
        "Пример: <code>Крипто Сигналы</code>",
        parse_mode="HTML",
    )


@router.message(AddProjectStates.name)
async def fsm_add_name(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id):
        return
    await state.update_data(name=message.text.strip())
    await state.set_state(AddProjectStates.slug)
    await message.answer(
        "Шаг 2/5 — Введите уникальный <b>slug</b> (латиница, без пробелов).\n"
        "Пример: <code>crypto_signals</code>",
        parse_mode="HTML",
    )


@router.message(AddProjectStates.slug)
async def fsm_add_slug(
    message: Message, state: FSMContext, repo_project: ProjectRepository
) -> None:
    if not is_admin(message.from_user.id):
        return
    slug = message.text.strip().lower().replace(" ", "_")
    existing = await repo_project.get_by_slug(slug)
    if existing:
        await message.answer(
            f"⚠️ Slug <code>{slug}</code> уже занят. Введите другой.",
            parse_mode="HTML",
        )
        return
    await state.update_data(slug=slug)
    await state.set_state(AddProjectStates.bot_token)
    await message.answer(
        "Шаг 3/5 — Вставьте <b>токен Telegram Бота</b> проекта\n"
        "(получить у @BotFather → /newbot):",
        parse_mode="HTML",
    )


@router.message(AddProjectStates.bot_token)
async def fsm_add_token(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id):
        return
    token = message.text.strip()
    if ":" not in token or len(token) < 40:
        await message.answer("⚠️ Похоже, токен невалидный. Попробуйте снова.")
        return
    await state.update_data(bot_token=token)
    await state.set_state(AddProjectStates.private_channel)
    await message.answer(
        "Шаг 4/5 — Введите <b>ID приватного канала</b>\n"
        "(бот должен быть администратором канала).\n"
        "Формат: <code>-1001234567890</code>",
        parse_mode="HTML",
    )


@router.message(AddProjectStates.private_channel)
async def fsm_add_channel(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id):
        return
    try:
        channel_id = int(message.text.strip())
    except ValueError:
        await message.answer("⚠️ ID канала должен быть числом (со знаком минус).")
        return

    await state.update_data(private_channel_id=channel_id)
    await state.set_state(AddProjectStates.news_invite_link)
    await message.answer(
        "Шаг 5/5 — Вставьте <b>ссылку-приглашение</b> на Новостной Канал.\n\n"
        "Это ссылка для кнопки «Подписаться» в боте.\n"
        "Для публичного канала: <code>https://t.me/имя_канала</code>\n"
        "Для приватного канала: <code>https://t.me/+xxxxxxxxxx</code>\n\n"
        "Ссылку можно найти в настройках канала → Пригласительные ссылки.",
        parse_mode="HTML",
    )


@router.message(AddProjectStates.news_invite_link)
async def fsm_add_news_link(message: Message, state: FSMContext) -> None:
    if not is_admin(message.from_user.id):
        return
    link = message.text.strip()
    if not link.startswith("https://t.me/"):
        await message.answer(
            "⚠️ Ссылка должна начинаться с <code>https://t.me/</code>\n"
            "Попробуйте снова.",
            parse_mode="HTML",
        )
        return

    await state.update_data(news_invite_link=link)
    await state.set_state(AddProjectStates.confirm)

    data = await state.get_data()
    await message.answer(
        f"✅ <b>Проверьте данные нового проекта:</b>\n\n"
        f"Название: <b>{data['name']}</b>\n"
        f"Slug: <code>{data['slug']}</code>\n"
        f"Токен: <code>{data['bot_token'][:12]}…</code>\n"
        f"Канал ID: <code>{data['private_channel_id']}</code>\n"
        f"Ссылка на новостной: {data['news_invite_link']}\n\n"
        f"Подтвердить? (отправьте <b>да</b> или <b>нет</b>)",
        parse_mode="HTML",
    )


@router.message(AddProjectStates.confirm)
async def fsm_add_confirm(
    message: Message,
    state: FSMContext,
    repo_project: ProjectRepository,
) -> None:
    if not is_admin(message.from_user.id):
        return

    if message.text.strip().lower() not in ("да", "yes", "y"):
        await state.clear()
        await message.answer("❌ Отменено.", reply_markup=kb_admin_main())
        return

    data = await state.get_data()
    await state.clear()

    news_channel_id = cfg.news_channel_id if cfg else 0

    project = await repo_project.create(
        name=data["name"],
        slug=data["slug"],
        bot_token=data["bot_token"],
        private_channel_id=data["private_channel_id"],
        news_channel_id=news_channel_id,
        news_channel_invite_link=data.get("news_invite_link"),
    )

    # Сразу активируем и запускаем бот без перезапуска системы
    await repo_project.set_status(project.id, ProjectStatus.active)

    from bot.orchestrator import ecosystem_manager
    launched = False
    if ecosystem_manager:
        # Перечитать проект из БД (уже active)
        fresh = await repo_project.get_by_id(project.id)
        if fresh:
            launched = await ecosystem_manager.start_project(fresh)

    status_line = (
        "🟢 Бот проекта запущен автоматически."
        if launched else
        "⚠️ Бот будет запущен при следующем перезапуске системы."
    )

    await message.answer(
        f"🎉 <b>Проект «{project.name}» создан!</b>\n\n"
        f"ID: <code>{project.id}</code>\n"
        f"Slug: <code>{project.slug}</code>\n\n"
        f"{status_line}",
        reply_markup=kb_admin_main(),
        parse_mode="HTML",
    )
    log.info("Создан и запущен новый проект: %s [%s]", project.name, project.slug)


# ─── Callback: общая статистика ───────────────────────────────────────────────

@router.callback_query(F.data == "admin:stats")
async def cb_global_stats(
    cb: CallbackQuery,
    repo_user: UserRepository,
    repo_project: ProjectRepository,
    repo_access: AccessRepository,
) -> None:
    if not is_admin(cb.from_user.id):
        return
    await cb.answer()

    total_users = await repo_user.count_all()
    projects = await repo_project.get_all()

    lines = []
    for p in projects:
        count = await repo_access.count_approved(p.id)
        icon = {"active": "✅", "paused": "⏸", "setup": "⚙️"}.get(p.status, "❓")
        lines.append(f"  {icon} {p.name}: <b>{count}</b> уч.")

    projects_text = "\n".join(lines) if lines else "  Нет проектов"

    # Статус запущенных ботов из оркестратора
    from bot.orchestrator import ecosystem_manager
    running = []
    if ecosystem_manager:
        running = ecosystem_manager.running_slugs()

    running_text = (
        "\n🤖 Запущены боты: " + ", ".join(f"<code>{s}</code>" for s in running)
        if running else ""
    )

    await cb.message.edit_text(
        f"📊 <b>Общая статистика экосистемы</b>\n\n"
        f"👥 Всего пользователей: <b>{total_users}</b>\n"
        f"📁 Проектов: <b>{len(projects)}</b>\n\n"
        f"Участники по проектам:\n{projects_text}"
        f"{running_text}",
        reply_markup=kb_back_to_admin(),
        parse_mode="HTML",
    )


# ─── /export — экспорт в CSV ──────────────────────────────────────────────────

@router.message(Command("export"))
async def cmd_export(
    message: Message,
    repo_project: ProjectRepository,
    repo_access: AccessRepository,
) -> None:
    if not is_admin(message.from_user.id):
        return

    from sqlalchemy import select
    from db.models import UserProjectAccess, User

    buf = StringIO()
    buf.write("telegram_id,username,first_name,project,status,traffic_source,registered_at,approved_at\n")

    projects = await repo_project.get_all()
    for project in projects:
        session = repo_access.session
        result = await session.execute(
            select(UserProjectAccess, User)
            .join(User, User.id == UserProjectAccess.user_id)
            .where(UserProjectAccess.project_id == project.id)
        )
        for access, user in result.all():
            buf.write(
                f"{user.telegram_id},"
                f"@{user.username or ''},"
                f"{(user.first_name or '').replace(',', ' ')},"
                f"{project.name},"
                f"{access.status},"
                f"{access.traffic_source_slug or ''},"
                f"{user.registered_at.strftime('%Y-%m-%d %H:%M') if user.registered_at else ''},"
                f"{access.approved_at.strftime('%Y-%m-%d %H:%M') if access.approved_at else ''}\n"
            )

    buf.seek(0)
    file = BufferedInputFile(buf.getvalue().encode("utf-8-sig"), filename="ecosystem_export.csv")
    await message.answer_document(file, caption="📊 Экспорт пользователей экосистемы")


# ─── Фабрика роутера (аналогично user.py) ────────────────────────────────────

def register_admin_handlers() -> Router:
    """
    Admin Bot создаётся один раз, но обёртка нужна для единообразия
    с register_user_handlers() и для явного контракта в orchestrator.py.
    """
    return router
