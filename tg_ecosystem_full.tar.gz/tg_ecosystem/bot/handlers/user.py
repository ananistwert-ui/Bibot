"""
bot/handlers/user.py

Воронка пользователя:
  /start → фото+текст+кнопка ВСТУПИТЬ
         → эмодзи-капча (случайная каждый раз)
         → проверка подписки на Новостной Канал (через Admin Bot)
         → invite link на приватный канал
         → автоодобрение join request
"""
import logging
import random

from aiogram import Bot, F, Router
from aiogram.filters import CommandStart
from aiogram.types import CallbackQuery, ChatJoinRequest, Message

from bot.keyboards import (
    generate_captcha, kb_captcha_emoji, kb_join_request,
    kb_start, kb_subscribe,
)
from db.models import AccessStatus, EventType, Project
from db.repositories import (
    AccessRepository, BlockedRepository, EventRepository,
    ProjectRepository, TrafficRepository, UserRepository,
)

log = logging.getLogger(__name__)
MAX_ATTEMPTS = 5   # лимит неверных нажатий капчи до блока


# ─── Фабрика роутеров ────────────────────────────────────────────────────────

def register_user_handlers() -> Router:
    """Каждый вызов — новый Router. Aiogram 3 запрещает shared routers."""
    router = Router(name="user")
    router.message.register(cmd_start, CommandStart())
    router.callback_query.register(cb_enter,              F.data == "start:enter")
    router.callback_query.register(cb_captcha_correct,    F.data.startswith("captcha:emoji:"))
    router.callback_query.register(cb_captcha_wrong,      F.data == "captcha:wrong")
    router.callback_query.register(cb_subscription_check, F.data == "subscription:check")
    router.callback_query.register(cb_noop,               F.data == "noop")
    router.chat_join_request.register(on_join_request)
    return router


# ─── Проверка подписки через Admin Bot ───────────────────────────────────────

async def check_subscription_via_admin(tg_user_id: int, news_channel_id: int) -> bool:
    """Admin Bot единственный имеет доступ к getChatMember Новостного Канала."""
    try:
        from bot.orchestrator import ecosystem_manager
        if not ecosystem_manager or not ecosystem_manager._admin_bot:
            log.error("Admin Bot недоступен для проверки подписки")
            return False
        member = await ecosystem_manager._admin_bot.get_chat_member(
            news_channel_id, tg_user_id
        )
        return member.status not in ("left", "kicked", "restricted")
    except Exception as e:
        log.warning("Ошибка проверки подписки: %s", e)
        return False


# ─── Вспомогательные ─────────────────────────────────────────────────────────

def _parse_source(text: str | None) -> str | None:
    if not text:
        return None
    parts = text.strip().split(maxsplit=1)
    return parts[1].lower()[:64] if len(parts) == 2 else None


def _welcome_text(project: Project) -> str:
    """Текст приветствия: кастомный из БД или дефолт."""
    if project.welcome_text:
        return project.welcome_text
    return (
        f"Добро пожаловать!\n"
        f"Вход в <b>{project.name}</b>"
    )


def _get_subscribe_link(project: Project) -> str:
    if project.news_channel_invite_link:
        return project.news_channel_invite_link
    return f"https://t.me/c/{str(project.news_channel_id).lstrip('-100')}"


async def _safe_edit(message: Message, **kwargs) -> None:
    """edit_text/edit_caption без падения на 'message is not modified'."""
    try:
        if message.photo:
            await message.edit_caption(**kwargs)
        else:
            await message.edit_text(**kwargs)
    except Exception as e:
        if "message is not modified" not in str(e):
            log.error("_safe_edit: %s", e)


# ─── ШАГ 0: /start — баннер + кнопка ВСТУПИТЬ ───────────────────────────────

async def cmd_start(
    message: Message,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_traffic: TrafficRepository,
    repo_blocked: BlockedRepository,
) -> None:
    if not project:
        return

    tg = message.from_user
    source_slug = _parse_source(message.text)

    user, is_new = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username,
        first_name=tg.first_name, last_name=tg.last_name,
    )

    if source_slug:
        await repo_traffic.track(project.id, source_slug)

    await repo_event.log(user.id, EventType.start, project.id,
                         meta={"source": source_slug, "is_new": is_new})

    if await repo_blocked.is_blocked(user.id, project.id):
        await message.answer("⛔️ Вы заблокированы в данном проекте.")
        return

    access, _ = await repo_access.get_or_create(
        user_id=user.id, project_id=project.id, traffic_source=source_slug,
    )

    if access.status == AccessStatus.approved:
        await message.answer("✅ Вы уже участник канала. Он в вашем списке каналов.")
        return

    welcome = _welcome_text(project)
    markup = kb_start()

    # Если задан баннер — отправляем фото+caption, иначе просто текст
    if project.welcome_banner_file_id:
        await message.answer_photo(
            photo=project.welcome_banner_file_id,
            caption=welcome,
            reply_markup=markup,
            parse_mode="HTML",
        )
    else:
        await message.answer(
            welcome,
            reply_markup=markup,
            parse_mode="HTML",
        )

    await repo_event.log(user.id, EventType.captcha_shown, project.id)


# ─── ШАГ 1: кнопка ВСТУПИТЬ → показ капчи ────────────────────────────────────

async def cb_enter(
    cb: CallbackQuery,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username, first_name=tg.first_name,
    )

    if await repo_blocked.is_blocked(user.id, project.id):
        await cb.answer("⛔️ Вы заблокированы.", show_alert=True)
        return

    access, _ = await repo_access.get_or_create(user.id, project.id)

    if access.captcha_verified:
        # Капча уже пройдена — сразу к подписке
        await cb.answer()
        await _show_subscription_step(cb.message, project, user.id, tg.id,
                                      repo_access, repo_event)
        return

    await cb.answer()
    await _show_captcha(cb.message)


async def _show_captcha(message: Message) -> None:
    """Генерируем новую случайную капчу и редактируем сообщение."""
    target_emoji, target_name, emojis = generate_captcha()
    text = (
        f"▰▱▱  Шаг 1 из 3 — Проверка\n\n"
        f"Нажмите на <b>{target_name}</b>:"
    )
    markup = kb_captcha_emoji(target_emoji, target_name, emojis)
    await _safe_edit(message, text=text, reply_markup=markup, parse_mode="HTML")


# ─── ШАГ 1: нажатие капчи ────────────────────────────────────────────────────

async def cb_captcha_correct(
    cb: CallbackQuery,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    """Пользователь нажал правильный эмодзи."""
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username, first_name=tg.first_name,
    )

    if await repo_blocked.is_blocked(user.id, project.id):
        await cb.answer("⛔️ Вы заблокированы.", show_alert=True)
        return

    await repo_access.set_captcha_verified(user.id, project.id)
    await repo_event.log(user.id, EventType.captcha_passed, project.id)
    await cb.answer("✅ Верно!")

    # Переходим к проверке подписки
    await _show_subscription_step(cb.message, project, user.id, tg.id,
                                   repo_access, repo_event)


async def cb_captcha_wrong(
    cb: CallbackQuery,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    """Пользователь нажал неверный эмодзи — новая задача + счётчик попыток."""
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username, first_name=tg.first_name,
    )

    if await repo_blocked.is_blocked(user.id, project.id):
        await cb.answer("⛔️ Вы заблокированы.", show_alert=True)
        return

    access, _ = await repo_access.get_or_create(user.id, project.id)
    attempts = await repo_access.increment_attempts(user.id, project.id)
    await repo_event.log(user.id, EventType.captcha_failed, project.id,
                         meta={"attempt": attempts})

    if attempts >= MAX_ATTEMPTS:
        await repo_blocked.block(user.id, project.id, reason="Лимит ошибок капчи")
        await repo_event.log(user.id, EventType.banned, project.id,
                             meta={"reason": "captcha_attempts"})
        await cb.answer("⛔️ Слишком много ошибок. Вы заблокированы.", show_alert=True)
        return

    remaining = MAX_ATTEMPTS - attempts
    await cb.answer(f"❌ Неверно. Осталось попыток: {remaining}", show_alert=False)

    # Новая капча
    await _show_captcha(cb.message)


# ─── ШАГ 2: подписка на Новостной Канал ──────────────────────────────────────

async def cb_subscription_check(
    cb: CallbackQuery,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(telegram_id=tg.id, username=tg.username)
    access = await repo_access.get(user.id, project.id)

    if not access or not access.captcha_verified:
        await cb.answer("⚠️ Сначала пройдите проверку.", show_alert=True)
        return

    is_subscribed = await check_subscription_via_admin(tg.id, project.news_channel_id)

    if not is_subscribed:
        await cb.answer(
            "❌ Вы ещё не вступили в канал.\nНажмите кнопку выше и вступите, затем вернитесь сюда.",
            show_alert=True,
        )
        await repo_event.log(user.id, EventType.sub_missing, project.id)
        return

    await cb.answer("✅ Отлично!")
    await _show_subscription_step(cb.message, project, user.id, tg.id,
                                   repo_access, repo_event)


async def _show_subscription_step(
    message: Message,
    project: Project,
    user_id: str,
    tg_user_id: int,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    is_subscribed = await check_subscription_via_admin(tg_user_id, project.news_channel_id)

    if not is_subscribed:
        await repo_event.log(user_id, EventType.sub_missing, project.id)
        subscribe_link = _get_subscribe_link(project)
        await _safe_edit(
            message,
            text=(
                "▰▰▱  Шаг 2 из 3 — Канал\n\n"
                "Вступите в наш новостной канал,\n"
                "затем нажмите «Я вступил»."
            ),
            reply_markup=kb_subscribe(subscribe_link),
            parse_mode="HTML",
        )
        return

    # Подписка подтверждена — переходим к invite link
    await repo_access.set_subscription_verified(user_id, project.id)
    await repo_event.log(user_id, EventType.sub_checked, project.id)
    await _send_join_link(message, project, user_id, repo_access, repo_event)


# ─── ШАГ 3: invite link в приватный канал ────────────────────────────────────

async def _send_join_link(
    message: Message,
    project: Project,
    user_id: str,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    try:
        from bot.orchestrator import ecosystem_manager
        project_bot: Bot | None = None
        if ecosystem_manager:
            entry = ecosystem_manager._running.get(project.slug)
            if entry:
                project_bot = entry.bot

        if not project_bot:
            raise RuntimeError("Бот проекта не найден в оркестраторе")

        link = await project_bot.create_chat_invite_link(
            chat_id=project.private_channel_id,
            creates_join_request=True,
            name=f"user_{user_id[:8]}",
        )
        invite_url = link.invite_link

    except Exception as e:
        log.error("Не удалось создать invite link: %s", e)
        await _safe_edit(
            message,
            text="❌ Ошибка создания ссылки. Убедитесь что бот — администратор канала.",
        )
        return

    await repo_access.set_request_at(user_id, project.id)
    await repo_event.log(user_id, EventType.join_request, project.id)

    await _safe_edit(
        message,
        text=(
            "▰▰▰  Шаг 3 из 3 — Доступ\n\n"
            "Нажмите кнопку ниже — заявка будет одобрена автоматически."
        ),
        reply_markup=kb_join_request(invite_url),
        parse_mode="HTML",
    )


# ─── ChatJoinRequest — автоодобрение ─────────────────────────────────────────

async def on_join_request(
    event: ChatJoinRequest,
    bot: Bot,
    repo_user: UserRepository,
    repo_project: ProjectRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    tg = event.from_user
    channel_id = event.chat.id

    project = await repo_project.get_by_channel_id(channel_id)
    if not project:
        log.warning("JoinRequest для неизвестного канала %s", channel_id)
        return

    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username,
        first_name=tg.first_name, last_name=tg.last_name,
    )
    access = await repo_access.get(user.id, project.id)

    reasons: list[str] = []

    if await repo_blocked.is_blocked(user.id, project.id):
        reasons.append("user_blocked")
    if not access or not access.captcha_verified:
        reasons.append("captcha_not_verified")
    if not access or not access.subscription_verified:
        subscribed = await check_subscription_via_admin(tg.id, project.news_channel_id)
        if not subscribed:
            reasons.append("not_subscribed")
        else:
            await repo_access.set_subscription_verified(user.id, project.id)

    if reasons:
        try:
            await bot.decline_chat_join_request(channel_id, tg.id)
        except Exception as e:
            log.error("Ошибка отклонения: %s", e)
        await repo_access.reject(user.id, project.id)
        await repo_event.log(user.id, EventType.rejected, project.id, meta={"reasons": reasons})
        log.info("JoinRequest отклонён: user=%s reasons=%s", tg.id, reasons)
        return

    try:
        await bot.approve_chat_join_request(channel_id, tg.id)
    except Exception as e:
        log.error("Ошибка одобрения: %s", e)
        return

    await repo_access.approve(user.id, project.id)
    await repo_event.log(user.id, EventType.approved, project.id)
    log.info("JoinRequest одобрен: user=%s project=%s", tg.id, project.slug)

    try:
        await bot.send_message(
            tg.id,
            f"🎉 <b>Добро пожаловать в {event.chat.title}!</b>\n\n"
            f"Вы теперь участник закрытого канала.\n"
            f"Закрепите его, чтобы не пропускать обновления.",
            parse_mode="HTML",
        )
    except Exception:
        pass


# ─── Noop ─────────────────────────────────────────────────────────────────────

async def cb_noop(cb: CallbackQuery) -> None:
    await cb.answer()
