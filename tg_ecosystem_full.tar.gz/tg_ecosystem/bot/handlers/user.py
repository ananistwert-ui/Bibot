"""
bot/handlers/user.py
Вся воронка пользователя:
  /start → CAPTCHA → проверка подписки → join request → одобрение
"""
import logging
from datetime import datetime, timezone

from aiogram import Bot, F, Router
from aiogram.filters import CommandStart
from aiogram.types import (
    CallbackQuery, ChatJoinRequest, Message,
)

from bot.keyboards import (
    kb_captcha, kb_join_request, kb_subscribe,
)
from db.models import AccessStatus, EventType, Project
from db.repositories import (
    AccessRepository, BlockedRepository, EventRepository,
    ProjectRepository, TrafficRepository, UserRepository,
)

log = logging.getLogger(__name__)
router = Router(name="user")

MAX_ATTEMPTS = 3  # максимум попыток CAPTCHA / заявок


# ─────────────────────────────────────────────────────────────────────────────
#  /start — точка входа
# ─────────────────────────────────────────────────────────────────────────────

@router.message(CommandStart())
async def cmd_start(
    message: Message,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_traffic: TrafficRepository,
    repo_blocked: BlockedRepository,
) -> None:
    if not project:
        return

    tg = message.from_user
    source_slug = _parse_source(message.text)

    # 1. Зарегистрировать / обновить пользователя
    user, is_new = await repo_user.get_or_create(
        telegram_id=tg.id,
        username=tg.username,
        first_name=tg.first_name,
        last_name=tg.last_name,
    )

    # 2. Зафиксировать источник трафика
    if source_slug:
        await repo_traffic.track(project.id, source_slug)

    # 3. Логируем старт
    await repo_event.log(
        user_id=user.id,
        event_type=EventType.start,
        project_id=project.id,
        meta={"source": source_slug, "is_new": is_new},
    )

    # 4. Проверить блокировку
    if await repo_blocked.is_blocked(user.id, project.id):
        await message.answer("⛔️ Вы заблокированы в данном проекте.")
        return

    # 5. Создать / получить запись доступа
    access, _ = await repo_access.get_or_create(
        user_id=user.id,
        project_id=project.id,
        traffic_source=source_slug,
    )

    # 6. Если уже одобрен — коротко уведомить
    if access.status == AccessStatus.approved:
        await message.answer(
            "✅ Вы уже являетесь участником канала.\n"
            "Проверьте список своих каналов в Telegram."
        )
        return

    # 7. Показать CAPTCHA (или напомнить пройти)
    await _show_captcha(message)
    await repo_event.log(
        user_id=user.id,
        event_type=EventType.captcha_shown,
        project_id=project.id,
    )


def _parse_source(text: str | None) -> str | None:
    """Извлечь slug источника из /start youtube → 'youtube'."""
    if not text:
        return None
    parts = text.strip().split(maxsplit=1)
    if len(parts) == 2:
        return parts[1].lower()[:64]
    return None


async def _show_captcha(message: Message) -> None:
    await message.answer(
        "👋 Добро пожаловать!\n\n"
        "Для доступа к каналу нажмите кнопку ниже, чтобы подтвердить, "
        "что вы не робот.",
        reply_markup=kb_captcha(),
    )


# ─────────────────────────────────────────────────────────────────────────────
#  Callback: CAPTCHA
# ─────────────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "captcha:verify")
async def cb_captcha_verify(
    cb: CallbackQuery,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id,
        username=tg.username,
        first_name=tg.first_name,
    )

    # Проверить блокировку
    if await repo_blocked.is_blocked(user.id, project.id):
        await cb.answer("⛔️ Вы заблокированы.", show_alert=True)
        return

    access, _ = await repo_access.get_or_create(user.id, project.id)

    # Антиспам: счётчик попыток
    if access.attempt_count >= MAX_ATTEMPTS and not access.captcha_verified:
        await repo_blocked.block(user.id, project.id, reason="Превышен лимит попыток CAPTCHA")
        await repo_event.log(user.id, EventType.banned, project.id,
                             meta={"reason": "captcha_attempts"})
        await cb.answer("⛔️ Слишком много попыток. Вы заблокированы.", show_alert=True)
        return

    # Зафиксировать прохождение CAPTCHA
    await repo_access.set_captcha_verified(user.id, project.id)
    await repo_event.log(user.id, EventType.captcha_passed, project.id)

    await cb.answer("✅ CAPTCHA пройдена!")

    # Перейти к проверке подписки
    await _check_subscription(cb.message, bot, project, user.id,
                              repo_access, repo_event)


# ─────────────────────────────────────────────────────────────────────────────
#  Callback: Проверка подписки
# ─────────────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "subscription:check")
async def cb_subscription_check(
    cb: CallbackQuery,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(telegram_id=tg.id, username=tg.username)
    access = await repo_access.get(user.id, project.id)

    if not access or not access.captcha_verified:
        await cb.answer("⚠️ Сначала пройдите CAPTCHA.", show_alert=True)
        return

    await cb.answer()
    await _check_subscription(cb.message, bot, project, user.id,
                              repo_access, repo_event)


async def _check_subscription(
    message: Message,
    bot: Bot,
    project: Project,
    user_id: str,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    """Проверить подписку на Новостной Канал и выдать следующий шаг."""
    # Получаем telegram_id из записи доступа (через join), 
    # но проще — взять из message.chat.id (это личный чат с ботом)
    tg_user_id = message.chat.id

    is_subscribed = await _is_subscribed(bot, tg_user_id, project.news_channel_id)

    if not is_subscribed:
        await repo_event.log(user_id, EventType.sub_missing, project.id)

        # Получаем username канала для ссылки
        try:
            chat = await bot.get_chat(project.news_channel_id)
            channel_link = chat.username or str(project.news_channel_id)
        except Exception:
            channel_link = str(project.news_channel_id)

        await message.edit_text(
            "📢 Для доступа к каналу необходимо подписаться на наш новостной канал.\n\n"
            "После подписки нажмите кнопку «Я подписался».",
            reply_markup=kb_subscribe(channel_link),
        )
        return

    # Подписка подтверждена
    await repo_access.set_subscription_verified(user_id, project.id)
    await repo_event.log(user_id, EventType.sub_checked, project.id)

    # Выдать ссылку для подачи заявки
    await _send_join_link(message, bot, project, user_id, repo_access, repo_event)


async def _is_subscribed(bot: Bot, tg_user_id: int, channel_id: int) -> bool:
    """Проверить через getChatMember."""
    try:
        member = await bot.get_chat_member(channel_id, tg_user_id)
        return member.status not in ("left", "kicked", "restricted")
    except Exception as e:
        log.warning("Ошибка проверки подписки: %s", e)
        return False


async def _send_join_link(
    message: Message,
    bot: Bot,
    project: Project,
    user_id: str,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    """Создать invite-link и отправить пользователю."""
    try:
        # Создаём одноразовый invite link с join request
        link = await bot.create_chat_invite_link(
            chat_id=project.private_channel_id,
            creates_join_request=True,
            name=f"user_{user_id[:8]}",
        )
        invite_url = link.invite_link
    except Exception as e:
        log.error("Не удалось создать invite link: %s", e)
        await message.edit_text(
            "❌ Ошибка при создании ссылки. Обратитесь к администратору."
        )
        return

    await repo_access.set_request_at(user_id, project.id)
    await repo_event.log(user_id, EventType.join_request, project.id)

    await message.edit_text(
        "✅ Подписка подтверждена!\n\n"
        "Нажмите кнопку ниже, чтобы подать заявку на вступление в закрытый канал.\n"
        "Заявка будет одобрена автоматически.",
        reply_markup=kb_join_request(invite_url),
    )


# ─────────────────────────────────────────────────────────────────────────────
#  ChatJoinRequest — автоматическое одобрение / отклонение
# ─────────────────────────────────────────────────────────────────────────────

@router.chat_join_request()
async def on_join_request(
    event: ChatJoinRequest,
    bot: Bot,
    repo_user: UserRepository,
    repo_project: ProjectRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    """
    Telegram присылает этот апдейт боту-администратору канала
    при каждой новой заявке на вступление.
    """
    tg = event.from_user
    channel_id = event.chat.id

    # Найти проект по ID приватного канала
    project = await repo_project.get_by_channel_id(channel_id)
    if not project:
        log.warning("JoinRequest для неизвестного канала %s", channel_id)
        return

    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id,
        username=tg.username,
        first_name=tg.first_name,
        last_name=tg.last_name,
    )

    access = await repo_access.get(user.id, project.id)

    # ── Финальные проверки перед одобрением ──────────────────────────────────
    reasons_to_reject: list[str] = []

    if await repo_blocked.is_blocked(user.id, project.id):
        reasons_to_reject.append("user_blocked")

    if not access or not access.captcha_verified:
        reasons_to_reject.append("captcha_not_verified")

    if not access or not access.subscription_verified:
        # Повторная проверка подписки в реальном времени
        subscribed = await _is_subscribed(bot, tg.id, project.news_channel_id)
        if not subscribed:
            reasons_to_reject.append("not_subscribed")
        else:
            await repo_access.set_subscription_verified(user.id, project.id)

    if reasons_to_reject:
        # Отклонить заявку
        try:
            await bot.decline_chat_join_request(channel_id, tg.id)
        except Exception as e:
            log.error("Ошибка отклонения заявки: %s", e)

        await repo_access.reject(user.id, project.id)
        await repo_event.log(
            user.id, EventType.rejected, project.id,
            meta={"reasons": reasons_to_reject}
        )
        log.info("JoinRequest отклонён: user=%s reasons=%s", tg.id, reasons_to_reject)
        return

    # ── Одобрить заявку ──────────────────────────────────────────────────────
    try:
        await bot.approve_chat_join_request(channel_id, tg.id)
    except Exception as e:
        log.error("Ошибка одобрения заявки: %s", e)
        return

    await repo_access.approve(user.id, project.id)
    await repo_event.log(user.id, EventType.approved, project.id)

    log.info("JoinRequest одобрен: user=%s project=%s", tg.id, project.slug)

    # Уведомить пользователя в личку (не критично если не дойдёт)
    try:
        await bot.send_message(
            tg.id,
            "🎉 Ваша заявка одобрена!\n"
            f"Вы вступили в канал <b>{event.chat.title}</b>.\n"
            "Добро пожаловать!",
            parse_mode="HTML",
        )
    except Exception:
        pass  # пользователь мог заблокировать бота


# ─────────────────────────────────────────────────────────────────────────────
#  Noop callback (заглушка для неактивных кнопок)
# ─────────────────────────────────────────────────────────────────────────────

@router.callback_query(F.data == "noop")
async def cb_noop(cb: CallbackQuery) -> None:
    await cb.answer()
