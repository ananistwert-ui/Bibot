"""
bot/handlers/user.py
Воронка пользователя: /start → CAPTCHA → подписка → join request → одобрение.

ВАЖНО: хендлеры регистрируются через register_user_handlers() — она каждый раз
возвращает новый Router, чтобы разные Dispatcher'ы не дрались за один объект.

ПРОВЕРКА ПОДПИСКИ: бот проекта не обязательно стоит в Новостном Канале.
Поэтому сначала пробуем через бот проекта, при ошибке — через Admin Bot.
"""
import logging
from aiogram import Bot, F, Router
from aiogram.filters import CommandStart
from aiogram.types import CallbackQuery, ChatJoinRequest, Message

from bot.keyboards import kb_captcha, kb_join_request, kb_subscribe
from core.config import config as cfg
from db.models import AccessStatus, EventType, Project
from db.repositories import (
    AccessRepository, BlockedRepository, EventRepository,
    ProjectRepository, TrafficRepository, UserRepository,
)

log = logging.getLogger(__name__)

MAX_ATTEMPTS = 3


# ─── Фабрика роутеров ────────────────────────────────────────────────────────

def register_user_handlers() -> Router:
    """
    Создаёт и возвращает новый Router с зарегистрированными хендлерами.
    Вызывается при каждом создании нового Dispatcher'а.
    """
    router = Router(name="user")

    router.message.register(cmd_start, CommandStart())
    router.callback_query.register(cb_captcha_verify, F.data == "captcha:verify")
    router.callback_query.register(cb_subscription_check, F.data == "subscription:check")
    router.callback_query.register(cb_noop, F.data == "noop")
    router.chat_join_request.register(on_join_request)

    return router


# ─── Вспомогательные функции ─────────────────────────────────────────────────

def _parse_source(text: str | None) -> str | None:
    if not text:
        return None
    parts = text.strip().split(maxsplit=1)
    return parts[1].lower()[:64] if len(parts) == 2 else None


async def _get_admin_bot() -> Bot | None:
    """Получить экземпляр Admin Bot из менеджера для проверки подписки."""
    try:
        from bot.orchestrator import ecosystem_manager
        if ecosystem_manager and ecosystem_manager._admin_bot:
            return ecosystem_manager._admin_bot
    except Exception:
        pass
    return None


async def _is_subscribed(bot: Bot, tg_user_id: int, channel_id: int) -> bool:
    """
    Проверить подписку пользователя на канал.

    Проблема: бот проекта может не быть участником/админом Новостного Канала,
    тогда getChatMember вернёт 'chat not found'.

    Решение: пробуем текущим ботом, при ошибке — Admin Bot'ом,
    который гарантированно добавлен в Новостной Канал.
    """
    async def _check(b: Bot) -> bool | None:
        try:
            member = await b.get_chat_member(channel_id, tg_user_id)
            return member.status not in ("left", "kicked", "restricted")
        except Exception as e:
            log.debug("_is_subscribed via bot %s: %s", b.id, e)
            return None

    # Пробуем текущим ботом
    result = await _check(bot)
    if result is not None:
        return result

    # Fallback: Admin Bot
    admin_bot = await _get_admin_bot()
    if admin_bot and admin_bot != bot:
        result = await _check(admin_bot)
        if result is not None:
            return result

    # Если оба недоступны — логируем и возвращаем False
    log.warning(
        "Не удалось проверить подписку user=%s channel=%s ни одним из ботов",
        tg_user_id, channel_id,
    )
    return False


async def _get_channel_username(bot: Bot, channel_id: int) -> str:
    """Получить username канала для ссылки. Пробует оба бота."""
    for b in [bot, await _get_admin_bot()]:
        if not b:
            continue
        try:
            chat = await b.get_chat(channel_id)
            if chat.username:
                return chat.username
        except Exception:
            continue
    # Фallback: числовой ID (кнопка откроет канал по ID)
    return str(channel_id)


# ─── /start ───────────────────────────────────────────────────────────────────

async def cmd_start(
    message: Message,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_traffic: TrafficRepository,
    repo_blocked: BlockedRepository,
) -> None:
    if not project:
        return

    tg = message.from_user
    source_slug = _parse_source(message.text)

    user, is_new = await repo_user.get_or_create(
        telegram_id=tg.id,
        username=tg.username,
        first_name=tg.first_name,
        last_name=tg.last_name,
    )

    if source_slug:
        await repo_traffic.track(project.id, source_slug)

    await repo_event.log(
        user_id=user.id,
        event_type=EventType.start,
        project_id=project.id,
        meta={"source": source_slug, "is_new": is_new},
    )

    if await repo_blocked.is_blocked(user.id, project.id):
        await message.answer("⛔️ Вы заблокированы в данном проекте.")
        return

    access, _ = await repo_access.get_or_create(
        user_id=user.id,
        project_id=project.id,
        traffic_source=source_slug,
    )

    if access.status == AccessStatus.approved:
        await message.answer(
            "✅ Вы уже являетесь участником канала.\n"
            "Проверьте список своих каналов в Telegram."
        )
        return

    await message.answer(
        "👋 Добро пожаловать!\n\n"
        "Для доступа к каналу нажмите кнопку ниже, чтобы подтвердить, "
        "что вы не робот.",
        reply_markup=kb_captcha(),
    )
    await repo_event.log(user.id, EventType.captcha_shown, project.id)


# ─── CAPTCHA ──────────────────────────────────────────────────────────────────

async def cb_captcha_verify(
    cb: CallbackQuery,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username, first_name=tg.first_name,
    )

    if await repo_blocked.is_blocked(user.id, project.id):
        await cb.answer("⛔️ Вы заблокированы.", show_alert=True)
        return

    access, _ = await repo_access.get_or_create(user.id, project.id)

    if access.attempt_count >= MAX_ATTEMPTS and not access.captcha_verified:
        await repo_blocked.block(user.id, project.id, reason="Превышен лимит попыток CAPTCHA")
        await repo_event.log(user.id, EventType.banned, project.id, meta={"reason": "captcha_attempts"})
        await cb.answer("⛔️ Слишком много попыток. Вы заблокированы.", show_alert=True)
        return

    await repo_access.set_captcha_verified(user.id, project.id)
    await repo_event.log(user.id, EventType.captcha_passed, project.id)
    await cb.answer("✅ CAPTCHA пройдена!")

    # Сразу проверяем подписку
    await _show_subscription_step(cb.message, bot, project, user.id, repo_access, repo_event)


# ─── Проверка подписки ────────────────────────────────────────────────────────

async def cb_subscription_check(
    cb: CallbackQuery,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(telegram_id=tg.id, username=tg.username)
    access = await repo_access.get(user.id, project.id)

    if not access or not access.captcha_verified:
        await cb.answer("⚠️ Сначала пройдите CAPTCHA.", show_alert=True)
        return

    is_subscribed = await _is_subscribed(bot, tg.id, project.news_channel_id)

    if not is_subscribed:
        await cb.answer(
            "❌ Подписка не найдена. Подпишитесь на канал и нажмите снова.",
            show_alert=True,
        )
        await repo_event.log(user.id, EventType.sub_missing, project.id)
        return

    await cb.answer("✅ Подписка подтверждена!")
    await _show_subscription_step(cb.message, bot, project, user.id, repo_access, repo_event)


async def _show_subscription_step(
    message: Message,
    bot: Bot,
    project: Project,
    user_id: str,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    """Показать шаг подписки или сразу перейти к выдаче ссылки."""
    tg_user_id = message.chat.id
    is_subscribed = await _is_subscribed(bot, tg_user_id, project.news_channel_id)

    if not is_subscribed:
        await repo_event.log(user_id, EventType.sub_missing, project.id)
        channel_username = await _get_channel_username(bot, project.news_channel_id)

        try:
            await message.edit_text(
                "📢 Для доступа необходимо подписаться на наш новостной канал.\n\n"
                "После подписки нажмите кнопку «Я подписался».",
                reply_markup=kb_subscribe(channel_username),
            )
        except Exception as e:
            if "message is not modified" not in str(e):
                log.error("edit_text ошибка: %s", e)
        return

    # Подписка есть — выдаём ссылку
    await repo_access.set_subscription_verified(user_id, project.id)
    await repo_event.log(user_id, EventType.sub_checked, project.id)
    await _send_join_link(message, bot, project, user_id, repo_access, repo_event)


async def _send_join_link(
    message: Message,
    bot: Bot,
    project: Project,
    user_id: str,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    try:
        link = await bot.create_chat_invite_link(
            chat_id=project.private_channel_id,
            creates_join_request=True,
            name=f"user_{user_id[:8]}",
        )
        invite_url = link.invite_link
    except Exception as e:
        log.error("Не удалось создать invite link: %s", e)
        await message.edit_text(
            "❌ Ошибка создания ссылки. Убедитесь что бот — администратор канала."
        )
        return

    await repo_access.set_request_at(user_id, project.id)
    await repo_event.log(user_id, EventType.join_request, project.id)

    try:
        await message.edit_text(
            "✅ Подписка подтверждена!\n\n"
            "Нажмите кнопку ниже, чтобы подать заявку на вступление.\n"
            "Заявка будет одобрена автоматически.",
            reply_markup=kb_join_request(invite_url),
        )
    except Exception as e:
        if "message is not modified" not in str(e):
            log.error("edit_text ошибка: %s", e)


# ─── ChatJoinRequest ──────────────────────────────────────────────────────────

async def on_join_request(
    event: ChatJoinRequest,
    bot: Bot,
    repo_user: UserRepository,
    repo_project: ProjectRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    tg = event.from_user
    channel_id = event.chat.id

    project = await repo_project.get_by_channel_id(channel_id)
    if not project:
        log.warning("JoinRequest для неизвестного канала %s", channel_id)
        return

    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username,
        first_name=tg.first_name, last_name=tg.last_name,
    )
    access = await repo_access.get(user.id, project.id)

    reasons_to_reject: list[str] = []

    if await repo_blocked.is_blocked(user.id, project.id):
        reasons_to_reject.append("user_blocked")

    if not access or not access.captcha_verified:
        reasons_to_reject.append("captcha_not_verified")

    if not access or not access.subscription_verified:
        subscribed = await _is_subscribed(bot, tg.id, project.news_channel_id)
        if not subscribed:
            reasons_to_reject.append("not_subscribed")
        else:
            await repo_access.set_subscription_verified(user.id, project.id)

    if reasons_to_reject:
        try:
            await bot.decline_chat_join_request(channel_id, tg.id)
        except Exception as e:
            log.error("Ошибка отклонения заявки: %s", e)
        await repo_access.reject(user.id, project.id)
        await repo_event.log(user.id, EventType.rejected, project.id, meta={"reasons": reasons_to_reject})
        log.info("JoinRequest отклонён: user=%s reasons=%s", tg.id, reasons_to_reject)
        return

    try:
        await bot.approve_chat_join_request(channel_id, tg.id)
    except Exception as e:
        log.error("Ошибка одобрения заявки: %s", e)
        return

    await repo_access.approve(user.id, project.id)
    await repo_event.log(user.id, EventType.approved, project.id)
    log.info("JoinRequest одобрен: user=%s project=%s", tg.id, project.slug)

    try:
        await bot.send_message(
            tg.id,
            f"🎉 Ваша заявка одобрена!\n"
            f"Вы вступили в канал <b>{event.chat.title}</b>.\nДобро пожаловать!",
            parse_mode="HTML",
        )
    except Exception:
        pass


# ─── Noop ─────────────────────────────────────────────────────────────────────

async def cb_noop(cb: CallbackQuery) -> None:
    await cb.answer()
