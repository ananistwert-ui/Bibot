"""
bot/handlers/user.py
Воронка: /start → CAPTCHA → подписка → join request → одобрение

АРХИТЕКТУРА ПРОВЕРКИ ПОДПИСКИ:
  - Admin Bot стоит в Новостном Канале как администратор
  - Admin Bot единственный кто вызывает getChatMember для Новостного Канала
  - Бот проекта запрашивает проверку у Admin Bot через ecosystem_manager
  - Кнопка "Подписаться" использует invite_link из БД (работает для pub/priv каналов)
"""
import logging
from aiogram import Bot, F, Router
from aiogram.filters import CommandStart
from aiogram.types import CallbackQuery, ChatJoinRequest, Message

from bot.keyboards import kb_captcha, kb_join_request, kb_subscribe
from db.models import AccessStatus, EventType, Project
from db.repositories import (
    AccessRepository, BlockedRepository, EventRepository,
    ProjectRepository, TrafficRepository, UserRepository,
)

log = logging.getLogger(__name__)
MAX_ATTEMPTS = 3


# ─── Фабрика роутеров ────────────────────────────────────────────────────────

def register_user_handlers() -> Router:
    """Каждый вызов возвращает новый Router — Aiogram 3 запрещает shared routers."""
    router = Router(name="user")
    router.message.register(cmd_start, CommandStart())
    router.callback_query.register(cb_captcha_verify,      F.data == "captcha:verify")
    router.callback_query.register(cb_subscription_check,  F.data == "subscription:check")
    router.callback_query.register(cb_noop,                F.data == "noop")
    router.chat_join_request.register(on_join_request)
    return router


# ─── Проверка подписки через Admin Bot ───────────────────────────────────────

async def check_subscription_via_admin(tg_user_id: int, news_channel_id: int) -> bool:
    """
    Admin Bot — единственный кто проверяет подписку.
    Он стоит в Новостном Канале и имеет право вызывать getChatMember.
    Боты проектов к каналу не имеют доступа и не должны иметь.
    """
    try:
        from bot.orchestrator import ecosystem_manager
        if not ecosystem_manager or not ecosystem_manager._admin_bot:
            log.error("Admin Bot недоступен для проверки подписки")
            return False

        admin_bot: Bot = ecosystem_manager._admin_bot
        member = await admin_bot.get_chat_member(news_channel_id, tg_user_id)
        return member.status not in ("left", "kicked", "restricted")

    except Exception as e:
        log.warning("Ошибка проверки подписки через Admin Bot: %s", e)
        return False


# ─── Вспомогательные ─────────────────────────────────────────────────────────

def _parse_source(text: str | None) -> str | None:
    if not text:
        return None
    parts = text.strip().split(maxsplit=1)
    return parts[1].lower()[:64] if len(parts) == 2 else None


def _get_subscribe_link(project: Project) -> str:
    """
    Возвращает ссылку для кнопки 'Подписаться'.
    Приоритет: invite_link из БД → fallback на числовой ID.
    """
    if project.news_channel_invite_link:
        return project.news_channel_invite_link
    # Fallback: публичный канал по ID (редкий случай если ссылка не задана)
    return f"https://t.me/c/{str(project.news_channel_id).lstrip('-100')}"


# ─── /start ───────────────────────────────────────────────────────────────────

async def cmd_start(
    message: Message,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_traffic: TrafficRepository,
    repo_blocked: BlockedRepository,
) -> None:
    if not project:
        return

    tg = message.from_user
    source_slug = _parse_source(message.text)

    user, is_new = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username,
        first_name=tg.first_name, last_name=tg.last_name,
    )

    if source_slug:
        await repo_traffic.track(project.id, source_slug)

    await repo_event.log(user.id, EventType.start, project.id,
                         meta={"source": source_slug, "is_new": is_new})

    if await repo_blocked.is_blocked(user.id, project.id):
        await message.answer("⛔️ Вы заблокированы в данном проекте.")
        return

    access, _ = await repo_access.get_or_create(
        user_id=user.id, project_id=project.id, traffic_source=source_slug,
    )

    if access.status == AccessStatus.approved:
        await message.answer(
            "✅ Вы уже являетесь участником канала.\n"
            "Проверьте список своих каналов в Telegram."
        )
        return

    await message.answer(
        "👋 Добро пожаловать!\n\n"
        "Для доступа к каналу нажмите кнопку ниже, чтобы подтвердить, "
        "что вы не робот.",
        reply_markup=kb_captcha(),
    )
    await repo_event.log(user.id, EventType.captcha_shown, project.id)


# ─── CAPTCHA ──────────────────────────────────────────────────────────────────

async def cb_captcha_verify(
    cb: CallbackQuery,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username, first_name=tg.first_name,
    )

    if await repo_blocked.is_blocked(user.id, project.id):
        await cb.answer("⛔️ Вы заблокированы.", show_alert=True)
        return

    access, _ = await repo_access.get_or_create(user.id, project.id)

    if access.attempt_count >= MAX_ATTEMPTS and not access.captcha_verified:
        await repo_blocked.block(user.id, project.id, reason="Лимит попыток CAPTCHA")
        await repo_event.log(user.id, EventType.banned, project.id,
                             meta={"reason": "captcha_attempts"})
        await cb.answer("⛔️ Слишком много попыток. Вы заблокированы.", show_alert=True)
        return

    await repo_access.set_captcha_verified(user.id, project.id)
    await repo_event.log(user.id, EventType.captcha_passed, project.id)
    await cb.answer("✅ CAPTCHA пройдена!")

    # Переходим к шагу подписки
    await _step_subscription(cb.message, project, user.id, tg.id, repo_access, repo_event)


# ─── Шаг подписки ────────────────────────────────────────────────────────────

async def cb_subscription_check(
    cb: CallbackQuery,
    bot: Bot,
    project: Project,
    repo_user: UserRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    if not project:
        return

    tg = cb.from_user
    user, _ = await repo_user.get_or_create(telegram_id=tg.id, username=tg.username)
    access = await repo_access.get(user.id, project.id)

    if not access or not access.captcha_verified:
        await cb.answer("⚠️ Сначала пройдите CAPTCHA.", show_alert=True)
        return

    # Проверяем через Admin Bot
    is_subscribed = await check_subscription_via_admin(tg.id, project.news_channel_id)

    if not is_subscribed:
        await cb.answer(
            "❌ Подписка не найдена.\nПодпишитесь на канал и нажмите снова.",
            show_alert=True,
        )
        await repo_event.log(user.id, EventType.sub_missing, project.id)
        return

    await cb.answer("✅ Подписка подтверждена!")
    await _step_subscription(cb.message, project, user.id, tg.id, repo_access, repo_event)


async def _step_subscription(
    message: Message,
    project: Project,
    user_id: str,
    tg_user_id: int,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    """Проверить подписку и выдать следующий шаг (ссылку или запрос подписки)."""
    is_subscribed = await check_subscription_via_admin(tg_user_id, project.news_channel_id)

    if not is_subscribed:
        await repo_event.log(user_id, EventType.sub_missing, project.id)
        subscribe_link = _get_subscribe_link(project)
        try:
            await message.edit_text(
                "📢 Для доступа необходимо подписаться на наш новостной канал.\n\n"
                "После подписки нажмите кнопку «Я подписался».",
                reply_markup=kb_subscribe(subscribe_link),
            )
        except Exception as e:
            if "message is not modified" not in str(e):
                log.error("edit_text: %s", e)
        return

    # Подписка есть — выдаём invite link на приватный канал
    await repo_access.set_subscription_verified(user_id, project.id)
    await repo_event.log(user_id, EventType.sub_checked, project.id)
    await _send_join_link(message, project, user_id, repo_access, repo_event)


async def _send_join_link(
    message: Message,
    project: Project,
    user_id: str,
    repo_access: AccessRepository,
    repo_event: EventRepository,
) -> None:
    """
    Создать одноразовый invite link на приватный канал.
    Бот проекта должен быть администратором приватного канала.
    """
    try:
        # Получаем бот проекта из оркестратора
        from bot.orchestrator import ecosystem_manager
        project_bot: Bot | None = None
        if ecosystem_manager:
            entry = ecosystem_manager._running.get(project.slug)
            if entry:
                project_bot = entry.bot

        if not project_bot:
            raise RuntimeError("Бот проекта не найден в оркестраторе")

        link = await project_bot.create_chat_invite_link(
            chat_id=project.private_channel_id,
            creates_join_request=True,
            name=f"user_{user_id[:8]}",
        )
        invite_url = link.invite_link

    except Exception as e:
        log.error("Не удалось создать invite link: %s", e)
        await message.edit_text(
            "❌ Ошибка создания ссылки.\n"
            "Убедитесь что бот является администратором приватного канала."
        )
        return

    await repo_access.set_request_at(user_id, project.id)
    await repo_event.log(user_id, EventType.join_request, project.id)

    try:
        await message.edit_text(
            "✅ Подписка подтверждена!\n\n"
            "Нажмите кнопку ниже, чтобы подать заявку на вступление.\n"
            "Заявка будет одобрена автоматически.",
            reply_markup=kb_join_request(invite_url),
        )
    except Exception as e:
        if "message is not modified" not in str(e):
            log.error("edit_text: %s", e)


# ─── ChatJoinRequest — автоодобрение ─────────────────────────────────────────

async def on_join_request(
    event: ChatJoinRequest,
    bot: Bot,
    repo_user: UserRepository,
    repo_project: ProjectRepository,
    repo_access: AccessRepository,
    repo_event: EventRepository,
    repo_blocked: BlockedRepository,
) -> None:
    tg = event.from_user
    channel_id = event.chat.id

    project = await repo_project.get_by_channel_id(channel_id)
    if not project:
        log.warning("JoinRequest для неизвестного канала %s", channel_id)
        return

    user, _ = await repo_user.get_or_create(
        telegram_id=tg.id, username=tg.username,
        first_name=tg.first_name, last_name=tg.last_name,
    )
    access = await repo_access.get(user.id, project.id)

    reasons_to_reject: list[str] = []

    if await repo_blocked.is_blocked(user.id, project.id):
        reasons_to_reject.append("user_blocked")

    if not access or not access.captcha_verified:
        reasons_to_reject.append("captcha_not_verified")

    if not access or not access.subscription_verified:
        # Финальная проверка подписки через Admin Bot
        subscribed = await check_subscription_via_admin(tg.id, project.news_channel_id)
        if not subscribed:
            reasons_to_reject.append("not_subscribed")
        else:
            await repo_access.set_subscription_verified(user.id, project.id)

    if reasons_to_reject:
        try:
            await bot.decline_chat_join_request(channel_id, tg.id)
        except Exception as e:
            log.error("Ошибка отклонения: %s", e)
        await repo_access.reject(user.id, project.id)
        await repo_event.log(user.id, EventType.rejected, project.id,
                             meta={"reasons": reasons_to_reject})
        log.info("JoinRequest отклонён: user=%s reasons=%s", tg.id, reasons_to_reject)
        return

    try:
        await bot.approve_chat_join_request(channel_id, tg.id)
    except Exception as e:
        log.error("Ошибка одобрения: %s", e)
        return

    await repo_access.approve(user.id, project.id)
    await repo_event.log(user.id, EventType.approved, project.id)
    log.info("JoinRequest одобрен: user=%s project=%s", tg.id, project.slug)

    try:
        await bot.send_message(
            tg.id,
            f"🎉 Ваша заявка одобрена!\n"
            f"Вы вступили в канал <b>{event.chat.title}</b>.\n"
            f"Добро пожаловать!",
            parse_mode="HTML",
        )
    except Exception:
        pass


# ─── Noop ─────────────────────────────────────────────────────────────────────

async def cb_noop(cb: CallbackQuery) -> None:
    await cb.answer()
