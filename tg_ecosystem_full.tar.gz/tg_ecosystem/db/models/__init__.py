"""
db/models/__init__.py
SQLAlchemy ORM-модели для всей экосистемы.
"""
import enum
import uuid
from datetime import datetime

from sqlalchemy import (
    BigInteger, Boolean, DateTime, Enum, ForeignKey,
    Integer, String, Text, UniqueConstraint, func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


# ─── Enum-типы ────────────────────────────────────────────────────────────────

class ProjectStatus(str, enum.Enum):
    active = "active"
    paused = "paused"
    setup  = "setup"


class AccessStatus(str, enum.Enum):
    pending  = "pending"    # заявка подана
    approved = "approved"   # доступ выдан
    rejected = "rejected"   # отклонён
    banned   = "banned"     # заблокирован


class EventType(str, enum.Enum):
    start          = "start"           # /start команда
    captcha_shown  = "captcha_shown"   # показана капча
    captcha_passed = "captcha_passed"  # капча пройдена
    captcha_failed = "captcha_failed"  # капча не пройдена
    sub_checked    = "sub_checked"     # подписка проверена
    sub_missing    = "sub_missing"     # нет подписки
    join_request   = "join_request"    # подана заявка
    approved       = "approved"        # одобрено
    rejected       = "rejected"        # отклонено
    banned         = "banned"          # заблокирован
    unbanned       = "unbanned"        # разблокирован


# ─── Таблица Projects ─────────────────────────────────────────────────────────

class Project(Base):
    """
    Один проект экосистемы.
    Каждый проект: переходник + бот + приватный канал.
    """
    __tablename__ = "projects"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True,
        default=lambda: str(uuid.uuid4())
    )
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    slug: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    bot_token: Mapped[str] = mapped_column(String(128), nullable=False)
    private_channel_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    news_channel_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    # Ссылка-приглашение на Новостной Канал (для кнопки "Подписаться")
    # ID используется для проверки через Admin Bot, ссылка — для кнопки
    news_channel_invite_link: Mapped[str | None] = mapped_column(String(256), nullable=True)
    status: Mapped[ProjectStatus] = mapped_column(
        Enum(ProjectStatus), default=ProjectStatus.setup, nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )

    # Relations
    accesses: Mapped[list["UserProjectAccess"]] = relationship(
        back_populates="project", cascade="all, delete-orphan"
    )
    events: Mapped[list["UserEvent"]] = relationship(
        back_populates="project", cascade="all, delete-orphan"
    )
    traffic_sources: Mapped[list["TrafficSource"]] = relationship(
        back_populates="project", cascade="all, delete-orphan"
    )
    blocked_users: Mapped[list["BlockedUser"]] = relationship(
        back_populates="project", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Project {self.slug} [{self.status}]>"


# ─── Таблица Users ────────────────────────────────────────────────────────────

class User(Base):
    """
    Telegram-пользователь.
    Один пользователь может быть в нескольких проектах.
    """
    __tablename__ = "users"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True,
        default=lambda: str(uuid.uuid4())
    )
    telegram_id: Mapped[int] = mapped_column(
        BigInteger, unique=True, nullable=False, index=True
    )
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    first_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    last_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    registered_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )

    # Relations
    accesses: Mapped[list["UserProjectAccess"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )
    events: Mapped[list["UserEvent"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )
    blocked_in: Mapped[list["BlockedUser"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<User @{self.username} [{self.telegram_id}]>"


# ─── Таблица UserProjectAccess ────────────────────────────────────────────────

class UserProjectAccess(Base):
    """
    Состояние пользователя в конкретном проекте.
    Отдельная запись для каждой пары user × project.
    """
    __tablename__ = "user_project_access"
    __table_args__ = (
        UniqueConstraint("user_id", "project_id", name="uq_user_project"),
    )

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True,
        default=lambda: str(uuid.uuid4())
    )
    user_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    project_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False
    )
    status: Mapped[AccessStatus] = mapped_column(
        Enum(AccessStatus), default=AccessStatus.pending, nullable=False
    )
    captcha_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    subscription_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    attempt_count: Mapped[int] = mapped_column(Integer, default=0)
    traffic_source_slug: Mapped[str | None] = mapped_column(String(64), nullable=True)
    request_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # Relations
    user: Mapped["User"] = relationship(back_populates="accesses")
    project: Mapped["Project"] = relationship(back_populates="accesses")


# ─── Таблица TrafficSource ────────────────────────────────────────────────────

class TrafficSource(Base):
    """
    Источники трафика привязаны к проекту.
    Создаются автоматически при первом /start с новым slug.
    """
    __tablename__ = "traffic_sources"
    __table_args__ = (
        UniqueConstraint("project_id", "slug", name="uq_project_source"),
    )

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True,
        default=lambda: str(uuid.uuid4())
    )
    project_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("projects.id", ondelete="CASCADE"), nullable=False
    )
    slug: Mapped[str] = mapped_column(String(64), nullable=False)
    label: Mapped[str | None] = mapped_column(String(128), nullable=True)
    total_clicks: Mapped[int] = mapped_column(Integer, default=0)

    project: Mapped["Project"] = relationship(back_populates="traffic_sources")


# ─── Таблица UserEvent ────────────────────────────────────────────────────────

class UserEvent(Base):
    """
    Лог всех действий пользователей.
    Для аналитики и антиспама.
    """
    __tablename__ = "user_events"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True,
        default=lambda: str(uuid.uuid4())
    )
    user_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    project_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("projects.id", ondelete="SET NULL"), nullable=True
    )
    event_type: Mapped[EventType] = mapped_column(Enum(EventType), nullable=False)
    meta: Mapped[str | None] = mapped_column(Text, nullable=True)  # JSON string
    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )

    user: Mapped["User"] = relationship(back_populates="events")
    project: Mapped["Project"] = relationship(back_populates="events")


# ─── Таблица BlockedUser ──────────────────────────────────────────────────────

class BlockedUser(Base):
    """
    Заблокированные пользователи.
    Блокировка применяется per-project или глобально (project_id=None).
    """
    __tablename__ = "blocked_users"
    __table_args__ = (
        UniqueConstraint("user_id", "project_id", name="uq_blocked_user_project"),
    )

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True,
        default=lambda: str(uuid.uuid4())
    )
    user_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    project_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("projects.id", ondelete="CASCADE"), nullable=True
    )
    reason: Mapped[str | None] = mapped_column(String(256), nullable=True)
    blocked_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )

    user: Mapped["User"] = relationship(back_populates="blocked_in")
    project: Mapped["Project"] = relationship(back_populates="blocked_users")
