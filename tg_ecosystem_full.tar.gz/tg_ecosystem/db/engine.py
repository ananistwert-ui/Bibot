"""
db/engine.py
Инициализация движка базы данных и фабрики сессий.
"""
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from db.models import Base

_engine = None
_session_factory = None


def get_engine(database_url: str):
    global _engine
    if _engine is None:
        connect_args = {}
        if "sqlite" in database_url:
            connect_args = {"check_same_thread": False}
        _engine = create_async_engine(
            database_url,
            echo=False,
            connect_args=connect_args,
        )
    return _engine


def get_session_factory(database_url: str) -> async_sessionmaker[AsyncSession]:
    global _session_factory
    if _session_factory is None:
        engine = get_engine(database_url)
        _session_factory = async_sessionmaker(
            engine, expire_on_commit=False, class_=AsyncSession
        )
    return _session_factory


async def init_db(database_url: str) -> None:
    """Создать все таблицы при первом запуске."""
    engine = get_engine(database_url)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
