"""
db/repositories/__init__.py
Все операции с базой данных. Бизнес-логика не здесь — только данные.
"""
import json
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from db.models import (
    AccessStatus, BlockedUser, EventType, Project, ProjectStatus,
    TrafficSource, User, UserEvent, UserProjectAccess,
)


# ─── UserRepository ───────────────────────────────────────────────────────────

class UserRepository:

    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_telegram_id(self, telegram_id: int) -> Optional[User]:
        result = await self.session.execute(
            select(User).where(User.telegram_id == telegram_id)
        )
        return result.scalar_one_or_none()

    async def get_or_create(
        self,
        telegram_id: int,
        username: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
    ) -> tuple[User, bool]:
        """Вернуть существующего пользователя или создать нового."""
        user = await self.get_by_telegram_id(telegram_id)
        if user:
            # Обновляем данные при каждом входе
            user.username = username
            user.first_name = first_name
            user.last_name = last_name
            await self.session.flush()
            return user, False

        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
        )
        self.session.add(user)
        await self.session.flush()
        return user, True

    async def count_all(self) -> int:
        result = await self.session.execute(select(func.count(User.id)))
        return result.scalar_one()


# ─── ProjectRepository ────────────────────────────────────────────────────────

class ProjectRepository:

    def __init__(self, session: AsyncSession):
        self.session = session

    async def get_by_id(self, project_id: str) -> Optional[Project]:
        return await self.session.get(Project, project_id)

    async def get_by_slug(self, slug: str) -> Optional[Project]:
        result = await self.session.execute(
            select(Project).where(Project.slug == slug)
        )
        return result.scalar_one_or_none()

    async def get_by_channel_id(self, channel_id: int) -> Optional[Project]:
        result = await self.session.execute(
            select(Project).where(Project.private_channel_id == channel_id)
        )
        return result.scalar_one_or_none()

    async def get_all_active(self) -> list[Project]:
        result = await self.session.execute(
            select(Project).where(Project.status == ProjectStatus.active)
        )
        return list(result.scalars().all())

    async def get_all(self) -> list[Project]:
        result = await self.session.execute(select(Project))
        return list(result.scalars().all())

    async def create(
        self,
        name: str,
        slug: str,
        bot_token: str,
        private_channel_id: int,
        news_channel_id: int,
        news_channel_invite_link: str | None = None,
    ) -> Project:
        project = Project(
            name=name,
            slug=slug,
            bot_token=bot_token,
            private_channel_id=private_channel_id,
            news_channel_id=news_channel_id,
            news_channel_invite_link=news_channel_invite_link,
            status=ProjectStatus.setup,
        )
        self.session.add(project)
        await self.session.flush()
        return project

    async def set_news_invite_link(self, project_id: str, link: str) -> None:
        """Обновить ссылку-приглашение на Новостной Канал."""
        await self.session.execute(
            update(Project)
            .where(Project.id == project_id)
            .values(news_channel_invite_link=link)
        )

    async def set_status(self, project_id: str, status: ProjectStatus) -> None:
        await self.session.execute(
            update(Project)
            .where(Project.id == project_id)
            .values(status=status)
        )


# ─── AccessRepository ─────────────────────────────────────────────────────────

class AccessRepository:

    def __init__(self, session: AsyncSession):
        self.session = session

    async def get(self, user_id: str, project_id: str) -> Optional[UserProjectAccess]:
        result = await self.session.execute(
            select(UserProjectAccess).where(
                UserProjectAccess.user_id == user_id,
                UserProjectAccess.project_id == project_id,
            )
        )
        return result.scalar_one_or_none()

    async def get_or_create(
        self, user_id: str, project_id: str, traffic_source: str | None = None
    ) -> tuple[UserProjectAccess, bool]:
        access = await self.get(user_id, project_id)
        if access:
            return access, False

        access = UserProjectAccess(
            user_id=user_id,
            project_id=project_id,
            traffic_source_slug=traffic_source,
        )
        self.session.add(access)
        await self.session.flush()
        return access, True

    async def set_captcha_verified(self, user_id: str, project_id: str) -> None:
        await self.session.execute(
            update(UserProjectAccess)
            .where(
                UserProjectAccess.user_id == user_id,
                UserProjectAccess.project_id == project_id,
            )
            .values(captcha_verified=True)
        )

    async def set_subscription_verified(self, user_id: str, project_id: str) -> None:
        await self.session.execute(
            update(UserProjectAccess)
            .where(
                UserProjectAccess.user_id == user_id,
                UserProjectAccess.project_id == project_id,
            )
            .values(subscription_verified=True)
        )

    async def set_request_at(self, user_id: str, project_id: str) -> None:
        await self.session.execute(
            update(UserProjectAccess)
            .where(
                UserProjectAccess.user_id == user_id,
                UserProjectAccess.project_id == project_id,
            )
            .values(
                request_at=datetime.now(timezone.utc),
                status=AccessStatus.pending,
            )
        )

    async def approve(self, user_id: str, project_id: str) -> None:
        await self.session.execute(
            update(UserProjectAccess)
            .where(
                UserProjectAccess.user_id == user_id,
                UserProjectAccess.project_id == project_id,
            )
            .values(
                status=AccessStatus.approved,
                approved_at=datetime.now(timezone.utc),
            )
        )

    async def reject(self, user_id: str, project_id: str) -> None:
        await self.session.execute(
            update(UserProjectAccess)
            .where(
                UserProjectAccess.user_id == user_id,
                UserProjectAccess.project_id == project_id,
            )
            .values(status=AccessStatus.rejected)
        )

    async def increment_attempts(self, user_id: str, project_id: str) -> int:
        """Увеличить счётчик попыток и вернуть новое значение."""
        access = await self.get(user_id, project_id)
        if not access:
            return 0
        access.attempt_count += 1
        await self.session.flush()
        return access.attempt_count

    async def count_approved(self, project_id: str) -> int:
        result = await self.session.execute(
            select(func.count(UserProjectAccess.id)).where(
                UserProjectAccess.project_id == project_id,
                UserProjectAccess.status == AccessStatus.approved,
            )
        )
        return result.scalar_one()


# ─── BlockedRepository ────────────────────────────────────────────────────────

class BlockedRepository:

    def __init__(self, session: AsyncSession):
        self.session = session

    async def is_blocked(
        self, user_id: str, project_id: str | None = None
    ) -> bool:
        """Проверить глобальную блокировку или в конкретном проекте."""
        # Глобальная блокировка
        result = await self.session.execute(
            select(BlockedUser).where(
                BlockedUser.user_id == user_id,
                BlockedUser.project_id.is_(None),
            )
        )
        if result.scalar_one_or_none():
            return True

        # Блокировка в проекте
        if project_id:
            result = await self.session.execute(
                select(BlockedUser).where(
                    BlockedUser.user_id == user_id,
                    BlockedUser.project_id == project_id,
                )
            )
            if result.scalar_one_or_none():
                return True

        return False

    async def block(
        self,
        user_id: str,
        project_id: str | None = None,
        reason: str | None = None,
    ) -> None:
        blocked = BlockedUser(
            user_id=user_id,
            project_id=project_id,
            reason=reason,
        )
        self.session.add(blocked)
        await self.session.flush()

    async def unblock(self, user_id: str, project_id: str | None = None) -> None:
        from sqlalchemy import delete
        await self.session.execute(
            delete(BlockedUser).where(
                BlockedUser.user_id == user_id,
                BlockedUser.project_id == project_id,
            )
        )


# ─── EventRepository ──────────────────────────────────────────────────────────

class EventRepository:

    def __init__(self, session: AsyncSession):
        self.session = session

    async def log(
        self,
        user_id: str,
        event_type: EventType,
        project_id: str | None = None,
        meta: dict | None = None,
    ) -> None:
        event = UserEvent(
            user_id=user_id,
            project_id=project_id,
            event_type=event_type,
            meta=json.dumps(meta, ensure_ascii=False) if meta else None,
        )
        self.session.add(event)
        await self.session.flush()

    async def recent(self, project_id: str, limit: int = 50) -> list[UserEvent]:
        result = await self.session.execute(
            select(UserEvent)
            .where(UserEvent.project_id == project_id)
            .order_by(UserEvent.created_at.desc())
            .limit(limit)
            .options(selectinload(UserEvent.user))
        )
        return list(result.scalars().all())


# ─── TrafficRepository ────────────────────────────────────────────────────────

class TrafficRepository:

    def __init__(self, session: AsyncSession):
        self.session = session

    async def track(self, project_id: str, slug: str) -> None:
        """Зафиксировать клик по источнику (создать если нет)."""
        result = await self.session.execute(
            select(TrafficSource).where(
                TrafficSource.project_id == project_id,
                TrafficSource.slug == slug,
            )
        )
        source = result.scalar_one_or_none()
        if source:
            source.total_clicks += 1
        else:
            source = TrafficSource(
                project_id=project_id,
                slug=slug,
                label=slug.capitalize(),
                total_clicks=1,
            )
            self.session.add(source)
        await self.session.flush()

    async def get_stats(self, project_id: str) -> list[TrafficSource]:
        result = await self.session.execute(
            select(TrafficSource)
            .where(TrafficSource.project_id == project_id)
            .order_by(TrafficSource.total_clicks.desc())
        )
        return list(result.scalars().all())
