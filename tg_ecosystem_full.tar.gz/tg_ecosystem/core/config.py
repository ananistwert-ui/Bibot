"""
core/config.py
Централизованная конфигурация всей экосистемы.
"""
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Config:
    admin_bot_token: str
    super_admin_id: int
    news_channel_id: int
    database_url: str
    redis_url: str | None

    # Антиспам
    max_attempts: int = 3          # макс попыток captcha/заявки
    attempt_window: int = 3600     # окно в секундах (1 час)
    cooldown_seconds: int = 300    # пауза между повторными заявками

    @classmethod
    def from_env(cls) -> "Config":
        token = os.getenv("ADMIN_BOT_TOKEN", "")
        if not token:
            raise ValueError("ADMIN_BOT_TOKEN не задан в .env")

        admin_id = os.getenv("SUPER_ADMIN_ID", "")
        if not admin_id:
            raise ValueError("SUPER_ADMIN_ID не задан в .env")

        news_channel = os.getenv("NEWS_CHANNEL_ID", "")
        if not news_channel:
            raise ValueError("NEWS_CHANNEL_ID не задан в .env")

        return cls(
            admin_bot_token=token,
            super_admin_id=int(admin_id),
            news_channel_id=int(news_channel),
            database_url=os.getenv(
                "DATABASE_URL",
                "sqlite+aiosqlite:///./ecosystem.db"
            ),
            redis_url=os.getenv("REDIS_URL"),
        )


# Глобальный объект конфигурации
config = Config.from_env() if os.getenv("ADMIN_BOT_TOKEN") else None
