"""
setup_project.py
Скрипт для добавления первого проекта в БД напрямую (без бота).
Запускать один раз после настройки .env.

Использование:
    python setup_project.py
"""
import asyncio
from db.engine import get_session_factory, init_db
from db.models import ProjectStatus
from db.repositories import ProjectRepository


async def setup():
    print("=" * 50)
    print("  Telegram Ecosystem — Первоначальная настройка")
    print("=" * 50)

    database_url = input("\nDatabase URL [sqlite+aiosqlite:///./ecosystem.db]: ").strip()
    if not database_url:
        database_url = "sqlite+aiosqlite:///./ecosystem.db"

    await init_db(database_url)
    session_factory = get_session_factory(database_url)

    print("\n--- Данные нового проекта ---")
    name              = input("Название проекта: ").strip()
    slug              = input("Slug (латиница): ").strip().lower().replace(" ", "_")
    bot_token         = input("Токен бота проекта: ").strip()
    private_channel   = int(input("ID приватного канала (-100...): ").strip())
    news_channel      = int(input("ID новостного канала (-100...): ").strip())

    async with session_factory() as session:
        async with session.begin():
            repo = ProjectRepository(session)
            existing = await repo.get_by_slug(slug)
            if existing:
                print(f"\n⚠️  Проект с slug '{slug}' уже существует!")
                return

            project = await repo.create(
                name=name,
                slug=slug,
                bot_token=bot_token,
                private_channel_id=private_channel,
                news_channel_id=news_channel,
            )
            # Сразу активируем
            await repo.set_status(project.id, ProjectStatus.active)

    print(f"\n✅ Проект '{name}' создан и активирован!")
    print(f"   ID: {project.id}")
    print(f"   Slug: {slug}")
    print(f"\nЗапустите систему: python main.py")


if __name__ == "__main__":
    asyncio.run(setup())
