"""
bot/keyboards/__init__.py
Все inline-клавиатуры экосистемы.
"""
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def kb_captcha() -> InlineKeyboardMarkup:
    """CAPTCHA — единственная кнопка."""
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="✅ Я человек",
            callback_data="captcha:verify"
        )
    ]])


def kb_subscribe(channel_username: str) -> InlineKeyboardMarkup:
    """Кнопки: подписаться + проверить.

    tg://resolve?domain=username открывает канал прямо в Telegram,
    не перебрасывая пользователя в браузер на telegram.org.
    """
    username = channel_username.lstrip("@")
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="📢 Подписаться на канал",
            url=f"tg://resolve?domain={username}",
        )],
        [InlineKeyboardButton(
            text="✅ Я подписался — проверить",
            callback_data="subscription:check",
        )],
    ])


def kb_join_request(invite_link: str) -> InlineKeyboardMarkup:
    """Кнопка для подачи заявки в приватный канал."""
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="🔑 Подать заявку на вступление",
            url=invite_link
        )
    ]])


def kb_already_in() -> InlineKeyboardMarkup:
    """Пользователь уже в канале."""
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="✅ Вы уже участник",
            callback_data="noop"
        )
    ]])


# ─── Admin keyboards ──────────────────────────────────────────────────────────

def kb_admin_main() -> InlineKeyboardMarkup:
    """Главное меню Супер Администратора."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 Список проектов", callback_data="admin:projects")],
        [InlineKeyboardButton(text="➕ Добавить проект",  callback_data="admin:add_project")],
        [InlineKeyboardButton(text="📊 Общая статистика", callback_data="admin:stats")],
        [InlineKeyboardButton(text="🚫 Заблокированные", callback_data="admin:blocked")],
    ])


def kb_admin_project(project_id: str) -> InlineKeyboardMarkup:
    """Меню управления конкретным проектом."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Статистика",       callback_data=f"proj:stats:{project_id}")],
        [InlineKeyboardButton(text="🔗 Источники трафика", callback_data=f"proj:traffic:{project_id}")],
        [InlineKeyboardButton(text="▶️ Активировать",     callback_data=f"proj:activate:{project_id}")],
        [InlineKeyboardButton(text="⏸ Приостановить",    callback_data=f"proj:pause:{project_id}")],
        [InlineKeyboardButton(text="🗑 Удалить",          callback_data=f"proj:delete:{project_id}")],
        [InlineKeyboardButton(text="◀️ Назад",            callback_data="admin:projects")],
    ])


def kb_back_to_admin() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="◀️ В меню", callback_data="admin:main")
    ]])


def kb_confirm_delete(project_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Да, удалить", callback_data=f"proj:delete_confirm:{project_id}")],
        [InlineKeyboardButton(text="❌ Отмена",      callback_data=f"proj:manage:{project_id}")],
    ])
