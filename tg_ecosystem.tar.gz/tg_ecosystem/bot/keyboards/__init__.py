"""
bot/keyboards/__init__.py
Все inline-клавиатуры экосистемы.
Тексты кнопок настраиваются через project.button_* поля или дефолты.
"""
import random
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

# ─── Эмодзи-капча ─────────────────────────────────────────────────────────────

# Набор пар (эмодзи, название) — из них каждый раз выбирается случайная цель
EMOJI_POOL = [
    ("🍎", "яблоко"),  ("🍋", "лимон"),   ("🍇", "виноград"),
    ("🌸", "цветок"),  ("⭐", "звезду"),   ("🔥", "огонь"),
    ("🌊", "волну"),   ("🎵", "ноту"),     ("🏆", "кубок"),
    ("🚀", "ракету"),  ("💎", "алмаз"),    ("🌈", "радугу"),
    ("🦋", "бабочку"), ("🍀", "клевер"),   ("🎯", "мишень"),
]

def generate_captcha() -> tuple[str, list[str]]:
    """
    Возвращает (callback_data_правильной_кнопки, список из 6 callback_data для кнопок).
    callback_data формат: captcha:emoji:СИМВОЛ
    """
    # Выбираем 6 случайных уникальных эмодзи
    chosen = random.sample(EMOJI_POOL, 6)
    # Цель — первый из выбранных
    target_emoji, target_name = chosen[0]
    # Перемешиваем порядок кнопок
    shuffled = chosen.copy()
    random.shuffle(shuffled)

    return target_emoji, target_name, [e for e, _ in shuffled]


def kb_captcha_emoji(target_emoji: str, target_name: str, emojis: list[str]) -> InlineKeyboardMarkup:
    """
    Сетка 3×2 с эмодзи. Правильная кнопка: captcha:emoji:TARGET
    Неправильные: captcha:wrong
    """
    buttons = []
    row = []
    for i, em in enumerate(emojis):
        if em == target_emoji:
            cb = f"captcha:emoji:{em}"
        else:
            cb = "captcha:wrong"
        row.append(InlineKeyboardButton(text=em, callback_data=cb))
        if len(row) == 3:
            buttons.append(row)
            row = []
    if row:
        buttons.append(row)
    return InlineKeyboardMarkup(inline_keyboard=buttons)


# ─── Остальные клавиатуры ─────────────────────────────────────────────────────

def kb_subscribe(invite_link: str, btn_text: str = "ВСТУПИТЬ В WHITEHOOD") -> InlineKeyboardMarkup:
    """
    Кнопка подписки на Новостной Канал.
    Текст кнопки можно переопределить через btn_text.
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text=f"📢 {btn_text}",
            url=invite_link,
        )],
        [InlineKeyboardButton(
            text="✅ Я вступил — проверить",
            callback_data="subscription:check",
        )],
    ])


def kb_join_request(invite_link: str, btn_text: str = "ДОСТУП В ПРИВАТ") -> InlineKeyboardMarkup:
    """Кнопка подачи заявки в приватный канал."""
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text=f"🔐 {btn_text}",
            url=invite_link,
        )
    ]])


def kb_start(btn_text: str = "ВСТУПИТЬ") -> InlineKeyboardMarkup:
    """Кнопка ВСТУПИТЬ на первом экране (фото+текст)."""
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text=f"🚀 {btn_text}", callback_data="start:enter")
    ]])


def kb_already_in() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Вы уже участник", callback_data="noop")
    ]])


# ─── Admin keyboards ──────────────────────────────────────────────────────────

def kb_admin_main() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 Список проектов",  callback_data="admin:projects")],
        [InlineKeyboardButton(text="➕ Добавить проект",  callback_data="admin:add_project")],
        [InlineKeyboardButton(text="📊 Общая статистика", callback_data="admin:stats")],
        [InlineKeyboardButton(text="🚫 Заблокированные",  callback_data="admin:blocked")],
    ])


def kb_admin_project(project_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 Статистика",        callback_data=f"proj:stats:{project_id}")],
        [InlineKeyboardButton(text="✏️ Текст приветствия", callback_data=f"proj:welcome:{project_id}")],
        [InlineKeyboardButton(text="🔗 Источники трафика", callback_data=f"proj:traffic:{project_id}")],
        [InlineKeyboardButton(text="▶️ Активировать",      callback_data=f"proj:activate:{project_id}")],
        [InlineKeyboardButton(text="⏸ Приостановить",     callback_data=f"proj:pause:{project_id}")],
        [InlineKeyboardButton(text="🗑 Удалить",           callback_data=f"proj:delete:{project_id}")],
        [InlineKeyboardButton(text="◀️ Назад",             callback_data="admin:projects")],
    ])


def kb_back_to_admin() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="◀️ В меню", callback_data="admin:main")
    ]])


def kb_confirm_delete(project_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Да, удалить", callback_data=f"proj:delete_confirm:{project_id}")],
        [InlineKeyboardButton(text="❌ Отмена",      callback_data=f"proj:manage:{project_id}")],
    ])
