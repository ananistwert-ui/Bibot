"""
db/engine.py
Инициализация движка базы данных и фабрики сессий.

ВАЖНО (производительность под systemd / 24×7):
Если используется SQLite, по умолчанию каждая транзакция держит
блокировку записи на ВЕСЬ файл БД. При нескольких ботах экосистемы,
работающих параллельно, это превращается в очередь, которая растёт
со временем (симптом: "работает, но с нарастающими задержками").

Здесь включается WAL-режим (читатели не блокируют писателя) и
busy_timeout (ждать лок вместо мгновенного исключения).
Для нагрузки выше нескольких проектов/десятков пользователей в
минуту — используйте PostgreSQL (docker-compose.yml уже настроен).
"""
import logging

from sqlalchemy import event as sa_event
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from db.models import Base

log = logging.getLogger(__name__)

_engine = None
_session_factory = None


def get_engine(database_url: str):
    global _engine
    if _engine is None:
        is_sqlite = "sqlite" in database_url
        connect_args = {"check_same_thread": False} if is_sqlite else {}

        _engine = create_async_engine(
            database_url,
            echo=False,
            connect_args=connect_args,
            # SQLite: NullPool — избегаем удержания соединения с
            # устаревшим состоянием WAL между разными event loop'ами.
            poolclass=NullPool if is_sqlite else None,
        )

        if is_sqlite:
            @sa_event.listens_for(_engine.sync_engine, "connect")
            def _set_sqlite_pragma(dbapi_conn, _):
                cur = dbapi_conn.cursor()
                # WAL: читатели не блокируются писателем, писатель не
                # блокируется читателями — резко снижает контеншн
                # между несколькими ботами на одной БД.
                cur.execute("PRAGMA journal_mode=WAL")
                # Если лок всё же занят — подождать до 5с вместо
                # немедленной ошибки "database is locked".
                cur.execute("PRAGMA busy_timeout=5000")
                cur.execute("PRAGMA synchronous=NORMAL")
                cur.close()

            log.warning(
                "Используется SQLite (%s). Включён WAL-режим. "
                "Для продакшна с несколькими активными проектами "
                "рекомендуется PostgreSQL (см. docker-compose.yml).",
                database_url,
            )
    return _engine


def get_session_factory(database_url: str) -> async_sessionmaker[AsyncSession]:
    global _session_factory
    if _session_factory is None:
        engine = get_engine(database_url)
        _session_factory = async_sessionmaker(
            engine, expire_on_commit=False, class_=AsyncSession
        )
    return _session_factory


async def init_db(database_url: str) -> None:
    """Создать все таблицы при первом запуске."""
    engine = get_engine(database_url)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
